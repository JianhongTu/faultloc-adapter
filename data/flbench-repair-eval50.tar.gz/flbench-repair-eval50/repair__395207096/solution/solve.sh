#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/unpack_utils.c b/src/unpack_utils.c
index 0289823..610faf0 100644
--- a/src/unpack_utils.c
+++ b/src/unpack_utils.c
@@ -506,8 +506,10 @@ static void *unpack_samples_worker_thread (void *param)
         if (cxt->state == Quit)                     // break out if we're done
             break;
 
-        if (cxt->samcnt > temp_samples)             // reallocate temp buffer if not big enough
+        if (cxt->samcnt > temp_samples) {           // reallocate temp buffer if not big enough
             temp_buffer = (int32_t *) realloc (temp_buffer, (temp_samples = cxt->samcnt) * 8);
+            memset (temp_buffer, 0, temp_samples * 8);
+        }
 
         // this is where the work is done
         unpack_samples_interleave (cxt->wps, cxt->outbuf, cxt->offset, temp_buffer, cxt->samcnt);

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 395207096: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
