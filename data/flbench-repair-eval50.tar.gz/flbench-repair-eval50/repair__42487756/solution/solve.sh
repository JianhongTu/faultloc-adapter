#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/libopensc/card-idprime.c b/src/libopensc/card-idprime.c
index e805da15f..70d18112e 100644
--- a/src/libopensc/card-idprime.c
+++ b/src/libopensc/card-idprime.c
@@ -526,24 +526,31 @@ static int idprime_read_binary(sc_card_t *card, unsigned int offset,
 	unsigned char *buf, size_t count, unsigned long flags)
 {
 	struct idprime_private_data *priv = card->drv_data;
-	int r;
+	int r = 0;
 	int size;
 
 	sc_log(card->ctx, "called; %"SC_FORMAT_LEN_SIZE_T"u bytes at offset %d",
 		count, offset);
 
 	if (!priv->cached && offset == 0) {
+		/* Read what was reported by FCI from select command */
+		int left = priv->file_size;
+		size_t read = 0;
+
 		// this function is called to read and uncompress the certificate
 		u8 buffer[SC_MAX_EXT_APDU_BUFFER_SIZE];
 		if (sizeof(buffer) < count) {
 			LOG_FUNC_RETURN(card->ctx, SC_ERROR_INTERNAL);
 		}
-		/* Read what was reported by FCI from select command */
-		r = iso_ops->read_binary(card, 0, buffer, priv->file_size, flags);
-		if (r < 0) {
-			LOG_FUNC_RETURN(card->ctx, r);
+		while (left > 0) {
+			r = iso_ops->read_binary(card, read, buffer + read, priv->file_size - read, flags);
+			if (r <= 0) {
+				LOG_FUNC_RETURN(card->ctx, r);
+			}
+			left -= r;
+			read += r;
 		}
-		if (r < 4) {
+		if (read < 4 || read != priv->file_size) {
 			LOG_FUNC_RETURN(card->ctx, SC_ERROR_INVALID_DATA);
 		}
 		if (buffer[0] == 1 && buffer[1] == 0) {

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42487756: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
