## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/src/media_tools/av_parsers.c b/src/media_tools/av_parsers.c
index bd4fcf27f..ec0df834a 100644
--- a/src/media_tools/av_parsers.c
+++ b/src/media_tools/av_parsers.c
@@ -7510,7 +7510,7 @@ static void gf_hevc_push_ref_poc(HEVCSliceInfo *si, s32 poc)
 	for (i=0;i<si->nb_reference_pocs; i++) {
 		if (si->reference_pocs[i]==poc) return;
 	}
-	if (si->nb_reference_pocs==30) return;
+	if (si->nb_reference_pocs==GF_ARRAY_LENGTH(si->reference_pocs)) return;
 	si->reference_pocs[si->nb_reference_pocs] = poc;
 	si->nb_reference_pocs++;
 }
@@ -12532,7 +12532,7 @@ static void vvc_push_ref_poc(VVCSliceInfo *si, s32 poc)
 	for (i=0;i<si->nb_reference_pocs; i++) {
 		if (si->reference_pocs[i]==poc) return;
 	}
-	if (si->nb_reference_pocs==30) return;
+	if (si->nb_reference_pocs==GF_ARRAY_LENGTH(si->reference_pocs)) return;
 	si->reference_pocs[si->nb_reference_pocs] = poc;
 	si->nb_reference_pocs++;
 }
```

It touches these lines, which are the ones to avoid:

- `src/media_tools/av_parsers.c` lines 7513-7513
- `src/media_tools/av_parsers.c` lines 12535-12535

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Stack-buffer-overflow WRITE 4
- Instrumentation: asan
- Entry point: fuzz_probe_analyze

```
Reading 121 bytes from /tmp/poc
<?xml version="1.0" encoding="UTF-8"?>
<GPACInspect>
<PIDConfigure PID="1" name="libfuzzer.6" SourcePath="/tmp/libfuzzer.6" URL="/tmp/libfuzzer.6" Extension="6" MIMEType="video/vvc" Cached="true" DownloadSize="121" StreamType="Visual" ID="1" Width="4294967293" Height="4294967285" FPS="25" Timescale="25000" CodecID="VVC Video" DecoderConfig="2 bytes (CRC32 0x9C118168)" Bitrate="24200" Duration="1000/25000" PlaybackMode="forward" Codec="vvc1.0.L0.CA">
<VVCParameterSets>
</VVCParameterSets>
</PIDConfigure>
<Packet number="1" PID="1" framing="complete" dts="0" cts="0" dur="1000" sap="1" ilace="0" corr="0" seek="0" bo="N/A" roll="0" crypt="0" vers="0" size="122" lp="0" depo="0" depf="0" red="0" CRC32="0xEA15CD59">
   <NALU size="39"  forbidden_zero="0" reserved_zero="0" layerID="0" nuh_type="15" temporalID="7" sps_id="0" vps_id="3" max_sublayers_minus1="4" chroma_format_idc="3" log2_ctu_size_minus5="1" sps_ptl_dpb_hrd_params_present_flag="0" gdr_enabled="1" ref_pic_resampling="0" width="2" height="1" conformance_window_present_flag="1" conformance_window_left="5" conformance_window_right="0" conformance_window_top="11" conformance_window_bottom="1" subpic_info_present="0" bitdepth_minus8="0" entropy_coding_sync_enabled_flag="1" entry_point_offsets_present_flag="0" log2_max_poc_lsb_minus4="2" poc_msb_cycle_flag="1" poc_msb_cycle_len_minus1="0" sps_num_extra_ph_bytes="1" extra_ph_bit_present_flag_1="0" extra_ph_bit_present_flag_1="0" extra_ph_bit_present_flag_1="0" extra_ph_bit_present_flag_1="0" extra_ph_bit_present_flag_1="0" extra_ph_bit_present_flag_1="0" extra_ph_bit_present_flag_1="0" extra_ph_bit_present_flag_1="0" num_extra_sh_bytes="0" sps_log2_min_luma_coding_block_size_minus2="7" sps_partition_constraints_override_enabled_flag="0" sps_log2_min_luma_coding_block_size_minus2="7" sps_max_mtt_hierarchy_depth_intra_slice_luma="15" sps_log2_diff_max_bt_min_qt_intra_slice_luma="6" sps_log2_diff_max_tt_min_qt_intra_slice_luma="2" sps_qtbtt_dual_tree_intra_flag="0" sps_log2_diff_min_qt_min_cb_inter_slice="2" sps_max_mtt_hierarchy_depth_inter_slice="11" sps_log2_diff_max_bt_min_qt_inter_slice="0" sps_log2_diff_max_tt_min_qt_inter_slice="0" sps_max_luma_transform_size_64_flag="0" sps_transform_skip_enabled_flag="0" sps_mts_enabled_flag="1" sps_explicit_mts_intra_enabled_flag="1" sps_explicit_mts_inter_enabled_flag="0" sps_lfnst_enabled_flag="0" sps_joint_cbcr_enabled_flag="1" sps_same_qp_table_for_chroma_flag="1" sps_qp_table_start_minus26_0="-1" sps_num_points_in_qp_table_minus1_0="12" sps_delta_qp_in_val_minus1_0_0="5" sps_delta_qp_diff_val_0_0="127" sps_delta_qp_in_val_minus1_0_1="0" sps_delta_qp_diff_val_0_1="129" sps_delta_qp_in_val_minus1_0_2="2" sps_delta_qp_diff_val_0_2="1" sps_delta_qp_in_val_minus1_0_3="0" sps_delta_qp_diff_val_0_3="5" sps_delta_qp_in_val_minus1_0_4="0" sps_delta_qp_diff_val_0_4="1" sps_delta_qp_in_val_minus1_0_5="2" sps_delta_qp_diff_val_0_5="1" sps_delta_qp_in_val_minus1_0_6="6" sps_delta_qp_diff_val_0_6="0" sps_delta_qp_in_val_minus1_0_7="15" sps_delta_qp_diff_val_0_7="0" sps_delta_qp_in_val_minus1_0_8="10" sps_delta_qp_diff_val_0_8="0" sps_delta_qp_in_val_minus1_0_9="0" sps_delta_qp_diff_val_0_9="0" sps_delta_qp_in_val_minus1_0_10="0" sps_delta_qp_diff_val_0_10="1" sps_delta_qp_in_val_minus1_0_11="0" sps_delta_qp_diff_val_0_11="7" sps_delta_qp_in_val_minus1_0_12="10" sps_delta_qp_diff_val_0_12="0" sps_sao_enabled_flag="0" sps_alf_enabled_flag="1" sps_ccalf_enabled_flag="1" sps_lmcs_enabled_flag="0" sps_weighted_pred_flag="0" sps_weighted_bipred_flag="0" sps_long_term_ref_pics_flag="0" sps_inter_layer_prediction_enabled_flag="0" sps_idr_rpl_present_flag="0" sps_rpl1_same_as_rpl0_flag="0" sps_num_ref_pic_lists_0="2" num_ref_entries_0_0="0" num_ref_entries_0_1="0" sps_num_ref_pic_lists_1="0" sps_ref_wraparound_enabled_flag="1" sps_temporal_mvp_enabled_flag="1" sps_sbtmvp_enabled_flag="0" sps_amvr_enabled_flag="1" sps_bdof_enabled_flag="1" sps_bdof_control_present_in_ph_flag="1" sps_smvd_enabled_flag="1" sps_dmvr_enabled_flag="1" sps_dmvr_control_present_in_ph_flag="0" sps_mmvd_enabled_flag="1" sps_mmvd_fullpel_only_enabled_flag="1" sps_six_minus_max_num_merge_cand="0" sps_sbt_enabled_flag="1" sps_affine_enabled_flag="1" sps_five_minus_max_num_subblock_merge_cand="0" sps_6param_affine_enabled_flag="1" sps_affine_amvr_enabled_flag="1" sps_affine_prof_enabled_flag="1" sps_prof_control_present_in_ph_flag="1" sps_bcw_enabled_flag="1" sps_ciip_enabled_flag="1" sps_gpm_enabled_flag="1" sps_max_num_merge_cand_minus_max_num_gpm_cand="0" sps_log2_parallel_merge_level_minus2="0" sps_isp_enabled_flag="1" sps_mrl_enabled_flag="1" sps_mip_enabled_flag="0" sps_cclm_enabled_flag="0" sps_palette_enabled_flag="0" sps_act_enabled_flag="0" sps_ibc_enabled_flag="0" sps_ladf_enabled_flag="0" sps_explicit_scaling_list_enabled_flag="0" sps_dep_quant_enabled_flag="0" sps_sign_data_hiding_enabled_flag="0" sps_virtual_boundaries_enabled_flag="0" sps_field_seq_flag="1" sps_vui_parameters_present_flag="0" type="SequenceParameterSet"/>
   <NALU size="19"  forbidden_zero="0" reserved_zero="0" layerID="32" nuh_type="16" temporalID="6" pps_id="0" sps_id="0" mixed_nal_types="1" width="3" height="509" conformance_window_flag="0" scaling_window_explicit_signaling_flag="1" scaling_win_left_offset="-31" scaling_win_right_offset="0" scaling_win_top_offset="0" scaling_win_bottom_offset="2" output_flag_present_flag="0" no_pic_partition_flag="0" subpic_id_mapping_present_flag="0" pps_log2_ctu_size_minus5="3" num_exp_tile_columns_minus1="0" num_exp_tile_rows_minus1="0" tile_column_width_minus1_0="0" tile_row_height_minus1_0="0" pps_loop_filter_across_tiles_enabled_flag="1" pps_rect_slice_flag="1" pps_single_slice_per_subpic_flag="1" pps_loop_filter_across_slices_enabled_flag="1" pps_cabac_init_present_flag="0" pps_num_ref_idx_default_active_minus1_0="14" pps_num_ref_idx_default_active_minus1_1="0" pps_rpl1_idx_present_flag="1" pps_weighted_pred_flag="1" pps_weighted_bipred_flag="1" pps_ref_wraparound_enabled_flag="1" pps_pic_width_minus_wraparound_offset="0" pps_init_qp_minus26="0" pps_cu_qp_delta_enabled_flag="1" pps_chroma_tool_offsets_present_flag="1" pps_cb_qp_offset="0" pps_cr_qp_offset="0" pps_joint_cbcr_qp_offset_present_flag="1" pps_joint_cbcr_qp_offset_value="0" pps_slice_chroma_qp_offsets_present_flag="1" pps_cu_chroma_qp_offset_list_enabled_flag="1" pps_chroma_qp_offset_list_len_minus1="0" pps_cb_qp_offset_list_0="1" pps_cr_qp_offset_list_0="1" pps_joint_cbcr_qp_offset_list_0="0" pps_deblocking_filter_control_present_flag="0" pps_rpl_info_in_ph_flag="1" pps_sao_info_in_ph_flag="1" pps_alf_info_in_ph_flag="1" pps_wp_info_in_ph_flag="1" pps_qp_delta_info_in_ph_flag="1" pps_picture_header_extension_present_flag="0" pps_slice_header_extension_present_flag="0" pps_extension_flag="0" type="PictureParameterSet"/>
   <NALU size="52"  forbidden_zero="0" reserved_zero="0" layerID="32" nuh_type="7" temporalID="6" picture_header_in_slice_header_flag="1" irap_or_gdr_pic="0" non_ref_pic="1" inter_slice_allowed_flag="1" intra_slice_allowed_flag="1" pps_id="0" poc_lsb="43" poc_msb_cycle_present_flag="1" poc_msb_cycle="1" ph_alf_enabled_flag="1" ph_num_alf_aps_ids_luma="1" ph_alf_aps_id_luma_0="4" ph_alf_cb_enabled_flag="1" ph_alf_cr_enabled_flag="0" ph_alf_aps_id_chroma="0" ph_alf_cc_cb_enabled_flag="0" ph_alf_cc_cr_enabled_flag="0" rpl_sps_flag_0="0" num_ref_entries_0_2="48" abs_delta_poc_st_0_2_0="2" strp_entry_sign_flag_0_2_0="0" abs_delta_poc_st_0_2_1="0" strp_entry_sign_flag_0_2_1="0" abs_delta_poc_st_0_2_2="4111" strp_entry_sign_flag_0_2_2="0" abs_delta_poc_st_0_2_3="3" strp_entry_sign_flag_0_2_3="0" abs_delta_poc_st_0_2_4="11" strp_entry_sign_flag_0_2_4="1" abs_delta_poc_st_0_2_5="1" strp_entry_sign_flag_0_2_5="0" abs_delta_poc_st_0_2_6="0" strp_entry_sign_flag_0_2_6="0" abs_delta_poc_st_0_2_7="63" strp_entry_sign_flag_0_2_7="0" abs_delta_poc_st_0_2_8="0" strp_entry_sign_flag_0_2_8="1" abs_delta_poc_st_0_2_9="5" strp_entry_sign_flag_0_2_9="0" abs_delta_poc_st_0_2_10="0" strp_entry_sign_flag_0_2_10="1" abs_delta_poc_st_0_2_11="2" strp_entry_sign_flag_0_2_11="0" abs_delta_poc_st_0_2_12="3" strp_entry_sign_flag_0_2_12="0" abs_delta_poc_st_0_2_13="15" strp_entry_sign_flag_0_2_13="0" abs_delta_poc_st_0_2_14="0" strp_entry_sign_flag_0_2_14="0" abs_delta_poc_st_0_2_15="0" strp_entry_sign_flag_0_2_15="1" abs_delta_poc_st_0_2_16="0" strp_entry_sign_flag_0_2_16="0" abs_delta_poc_st_0_2_17="1" strp_entry_sign_flag_0_2_17="0" abs_delta_poc_st_0_2_18="126" strp_entry_sign_flag_0_2_18="1" abs_delta_poc_st_0_2_19="3" strp_entry_sign_flag_0_2_19="0" abs_delta_poc_st_0_2_20="6" strp_entry_sign_flag_0_2_20="1" abs_delta_poc_st_0_2_21="0" strp_entry_sign_flag_0_2_21="1" abs_delta_poc_st_0_2_22="0" strp_entry_sign_flag_0_2_22="1" abs_delta_poc_st_0_2_23="0" strp_entry_sign_flag_0_2_23="0" abs_delta_poc_st_0_2_24="2" strp_entry_sign_flag_0_2_24="0" abs_delta_poc_st_0_2_25="0" strp_entry_sign_flag_0_2_25="0" abs_delta_poc_st_0_2_26="3" strp_entry_sign_flag_0_2_26="0" abs_delta_poc_st_0_2_27="15" strp_entry_sign_flag_0_2_27="0" abs_delta_poc_st_0_2_28="0" strp_entry_sign_flag_0_2_28="1" abs_delta_poc_st_0_2_29="0" strp_entry_sign_flag_0_2_29="1" abs_delta_poc_st_0_2_30="0" strp_entry_sign_flag_0_2_30="1" abs_delta_poc_st_0_2_31="0" strp_entry_sign_flag_0_2_31="1" abs_delta_poc_st_0_2_32="5" strp_entry_sign_flag_0_2_32="1" abs_delta_poc_st_0_2_33="0" strp_entry_sign_flag_0_2_33="0" abs_delta_poc_st_0_2_34="3" strp_entry_sign_flag_0_2_34="0" abs_delta_poc_st_0_2_35="5" strp_entry_sign_flag_0_2_35="0" abs_delta_poc_st_0_2_36="22" strp_entry_sign_flag_0_2_36="0" abs_delta_poc_st_0_2_37="1" strp_entry_sign_flag_0_2_37="0" abs_delta_poc_st_0_2_38="126" strp_entry_sign_flag_0_2_38="1" abs_delta_poc_st_0_2_39="3" strp_entry_sign_flag_0_2_39="0" abs_delta_poc_st_0_2_40="6" strp_entry_sign_flag_0_2_40="1" abs_delta_poc_st_0_2_41="0" strp_entry_sign_flag_0_2_41="1" abs_delta_poc_st_0_2_42="0" strp_entry_sign_flag_0_2_42="1" abs_delta_poc_st_0_2_43="0" strp_entry_sign_flag_0_2_43="0" abs_delta_poc_st_0_2_44="2" strp_entry_sign_flag_0_2_44="0" abs_delta_poc_st_0_2_45="0" strp_entry_sign_flag_0_2_45="0" abs_delta_poc_st_0_2_46="3" strp_entry_sign_flag_0_2_46="0" abs_delta_poc_st_0_2_47="15" strp_entry_sign_flag_0_2_47="0" num_ref_entries_1_0="3" abs_delta_poc_st_1_0_0="31" strp_entry_sign_flag_1_0_0="1" abs_delta_poc_st_1_0_1="0" strp_entry_sign_flag_1_0_1="1" abs_delta_poc_st_1_0_2="0" strp_entry_sign_flag_1_0_2="1" ph_cu_qp_delta_subdiv_inter_slice="0" ph_cu_chroma_qp_offset_subdiv_intra_slice="0" ph_cu_qp_delta_subdiv_inter_slice="0" ph_cu_chroma_qp_offset_subdiv_inter_slice="0" ph_temporal_mvp_enabled_flag="1" ph_collocated_from_l0_flag="1" ph_collocated_ref_idx="0" ph_mmvd_fullpel_only_flag="1" ph_mvd_l1_zero_flag="1" ph_bdof_disabled_flag="1" ph_prof_disabled_flag="1" luma_log2_weight_denom="10" delta_chroma_log2_weight_denom="0" num_l0_weights="0" num_l1_weight[33m[VVC] Align bit at end of slice header not set to 1 !
[0m=================================================================
[1m[31m==6==ERROR: AddressSanitizer: stack-buffer-overflow on address 0x7f8ddbf7c630 at pc 0x55ea20bf48cb bp 0x7ffc6cbc4f70 sp 0x7ffc6cbc4f68
[1m[0m[1m[34mWRITE of size 4 at 0x7f8ddbf7c630 thread T0[1m[0m
SCARINESS: 51 (4-byte-write-stack-buffer-overflow)
    #0 0x55ea20bf48ca in vvc_push_ref_poc /src/gpac/src/media_tools/av_parsers.c:12536:44
    #1 0x55ea20bf48ca in vvc_compute_refs /src/gpac/src/media_tools/av_parsers.c:12574:4
    #2 0x55ea20bf48ca in gf_vvc_parse_nalu_bs /src/gpac/src/media_tools/av_parsers.c:12627:5
    #3 0x55ea1fc6fe4a in gf_inspect_dump_nalu_internal /src/gpac/src/filters/inspect.c:1170:10
    #4 0x55ea1fc85cf7 in inspect_dump_packet /src/gpac/src/filters/inspect.c:3651:5
    #5 0x55ea1fc85cf7 in inspect_process /src/gpac/src/filters/inspect.c:5134:6
    #6 0x55ea1f9c0642 in gf_filter_process_task /src/gpac/src/filter_core/filter.c:3171:7
    #7 0x55ea1f985fed in gf_fs_thread_proc /src/gpac/src/filter_core/filter_session.c:2156:3
    #8 0x55ea1f982102 in gf_fs_run /src/gpac/src/filter_core/filter_session.c:2463:3
    #9 0x55ea1f94ac70 in LLVMFuzzerTestOneInput /src/gpac/testsuite/oss-fuzzers/fuzz_probe_analyze.c:22:5
    #10 0x55ea1f94aa49 in ExecuteFilesOnyByOne /src/aflplusplus/utils/aflpp_driver/aflpp_driver.c:255:7
    #11 0x55ea1f94a845 in LLVMFuzzerRunDriver /src/aflplusplus/utils/aflpp_driver/aflpp_driver.c
    #12 0x55ea1f94a3fd in main /src/aflplusplus/utils/aflpp_driver/aflpp_driver.c:311:10
    #13 0x7f8ddc4bd082 in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x24082) (BuildId: 0702430aef5fa3dda43986563e9ffcc47efbd75e)
    #14 0x55ea1f86fe8d in _start (/out/fuzz_probe_analyze+0x2cee8d)

DEDUP_TOKEN: vvc_push_ref_poc--vvc_compute_refs--gf_vvc_parse_nalu_bs
[1m[32mAddress 0x7f8ddbf7c630 is located in stack of thread T0 at offset 1584 in frame[1m[0m
[1m[0m    #0 0x55ea20bee74f in gf_vvc_parse_nalu_bs /src/gpac/src/media_tools/av_parsers.c:12581

DEDUP_TOKEN: gf_vvc_parse_nalu_bs
  This frame has 1 object(s):
    [32, 1584) 'n_state' (line 12585)[1m[32m <== Memory access at offset 1584 overflows this variable[1m[0m
HINT: this may be a false positive if your program uses some custom stack unwind mechanism, swapcontext or vfork
      (longjmp and C++ exceptions *are* supported)
SUMMARY: AddressSanitizer: stack-buffer-overflow /src/gpac/src/media_tools/av_parsers.c:12536:44 in vvc_push_ref_poc
Shadow bytes around the buggy address:
  0x7f8ddbf7c380: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x7f8ddbf7c400: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x7f8ddbf7c480: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x7f8ddbf7c500: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x7f8ddbf7c580: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
=>0x7f8ddbf7c600: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m[[1m[31mf3[1m[0m][1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m
  0x7f8ddbf7c680: [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x7f8ddbf7c700: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x7f8ddbf7c780: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x7f8ddbf7c800: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x7f8ddbf7c880: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
Shadow byte legend (one shadow byte represents 8 application bytes):
  Addressable:           [1m[0m00[1m[0m
  Partially addressable: [1m[0m01[1m[0m [1m[0m02[1m[0m [1m[0m03[1m[0m [1m[0m04[1m[0m [1m[0m05[1m[0m [1m[0m06[1m[0m [1m[0m07[1m[0m
  Heap left redzone:       [1m[31mfa[1m[0m
  Freed heap region:       [1m[35mfd[1m[0m
  Stack left redzone:      [1m[31mf1[1m[0m
  Stack mid redzone:       [1m[31mf2[1m[0m
  Stack right redzone:     [1m[31mf3[1m[0m
  Stack after return:      [1m[35mf5[1m[0m
  Stack use after scope:   [1m[35mf8[1m[0m
  Global redzone:          [1m[31mf9[1m[0m
  Global init order:       [1m[36mf6[1m[0m
  Poisoned by user:        [1m[34mf7[1m[0m
  Container overflow:      [1m[34mfc[1m[0m
  Array cookie:            [1m[31mac[1m[0m
  Intra object redzone:    [1m[33mbb[1m[0m
  ASan internal:           [1m[33mfe[1m[0m
  Left alloca redzone:     [1m[34mca[1m[0m
  Right alloca redzone:    [1m[34mcb[1m[0m
==6==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
