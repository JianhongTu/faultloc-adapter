#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/media_tools/av_parsers.c b/src/media_tools/av_parsers.c
index bd4fcf27f..ec0df834a 100644
--- a/src/media_tools/av_parsers.c
+++ b/src/media_tools/av_parsers.c
@@ -7510,7 +7510,7 @@ static void gf_hevc_push_ref_poc(HEVCSliceInfo *si, s32 poc)
 	for (i=0;i<si->nb_reference_pocs; i++) {
 		if (si->reference_pocs[i]==poc) return;
 	}
-	if (si->nb_reference_pocs==30) return;
+	if (si->nb_reference_pocs==GF_ARRAY_LENGTH(si->reference_pocs)) return;
 	si->reference_pocs[si->nb_reference_pocs] = poc;
 	si->nb_reference_pocs++;
 }
@@ -12532,7 +12532,7 @@ static void vvc_push_ref_poc(VVCSliceInfo *si, s32 poc)
 	for (i=0;i<si->nb_reference_pocs; i++) {
 		if (si->reference_pocs[i]==poc) return;
 	}
-	if (si->nb_reference_pocs==30) return;
+	if (si->nb_reference_pocs==GF_ARRAY_LENGTH(si->reference_pocs)) return;
 	si->reference_pocs[si->nb_reference_pocs] = poc;
 	si->nb_reference_pocs++;
 }

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42537243: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
