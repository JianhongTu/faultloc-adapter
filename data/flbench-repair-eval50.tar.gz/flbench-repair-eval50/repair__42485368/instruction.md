## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/cpp/src/arrow/array/validate.cc b/cpp/src/arrow/array/validate.cc
index f42296165..bdb8a7d22 100644
--- a/cpp/src/arrow/array/validate.cc
+++ b/cpp/src/arrow/array/validate.cc
@@ -216,7 +216,28 @@ struct ValidateArrayVisitor {
     if (array.value_data() == nullptr) {
       return Status::Invalid("value data buffer is null");
     }
-    return ValidateOffsets(array);
+    RETURN_NOT_OK(ValidateOffsets(array));
+
+    if (array.length() > 0) {
+      const auto first_offset = array.value_offset(0);
+      const auto last_offset = array.value_offset(array.length());
+      if (first_offset < 0 || last_offset < 0) {
+        return Status::Invalid("Negative offsets in binary array");
+      }
+      const auto data_extent = last_offset - first_offset;
+      const auto values_length = array.value_data()->size();
+      if (values_length < data_extent) {
+        return Status::Invalid("Length spanned by binary offsets (", data_extent,
+                               ") larger than values array (size ", values_length, ")");
+      }
+      if (first_offset > values_length || last_offset > values_length) {
+        return Status::Invalid("First or last binary offset out of bounds");
+      }
+      if (first_offset > last_offset) {
+        return Status::Invalid("First offset larger than last offset in binary array");
+      }
+    }
+    return Status::OK();
   }
 
   template <typename ListArrayType>
@@ -228,7 +249,6 @@ struct ValidateArrayVisitor {
     if (array.length() > 0) {
       const auto first_offset = array.value_offset(0);
       const auto last_offset = array.value_offset(array.length());
-      // This early test avoids undefined behaviour when computing `data_extent`
       if (first_offset < 0 || last_offset < 0) {
         return Status::Invalid("Negative offsets in list array");
       }
@@ -241,6 +261,12 @@ struct ValidateArrayVisitor {
         return Status::Invalid("Length spanned by list offsets (", data_extent,
                                ") larger than values array (length ", values_length, ")");
       }
+      if (first_offset > values_length || last_offset > values_length) {
+        return Status::Invalid("First or last list offset out of bounds");
+      }
+      if (first_offset > last_offset) {
+        return Status::Invalid("First offset larger than last offset in list array");
+      }
     }
 
     const Status child_valid = ValidateArray(*array.values());
diff --git a/cpp/src/arrow/ipc/reader.cc b/cpp/src/arrow/ipc/reader.cc
index 20cab041e..8d5942d8e 100644
--- a/cpp/src/arrow/ipc/reader.cc
+++ b/cpp/src/arrow/ipc/reader.cc
@@ -684,6 +684,7 @@ Status ReadDictionary(const Buffer& metadata, DictionaryMemo* dictionary_memo,
     return Status::Invalid("Dictionary record batch must only contain one field");
   }
   auto dictionary = batch->column(0);
+  RETURN_NOT_OK(dictionary->Validate());
   if (dictionary_batch->isDelta()) {
     return dictionary_memo->AddDictionaryDelta(id, dictionary, options.memory_pool);
   }
@@ -739,18 +740,18 @@ class RecordBatchStreamReaderImpl : public RecordBatchStreamReader {
 
     std::unique_ptr<Message> message;
     ARROW_ASSIGN_OR_RAISE(message, message_reader_->ReadNextMessage());
+
+    while (message != nullptr && message->type() == MessageType::DICTIONARY_BATCH) {
+      RETURN_NOT_OK(UpdateDictionaries(*message, &dictionary_memo_, options_));
+      ARROW_ASSIGN_OR_RAISE(message, message_reader_->ReadNextMessage());
+    }
+
     if (message == nullptr) {
       // End of stream
       *batch = nullptr;
       return Status::OK();
     }
 
-    // continue to read other dictionaries, if any
-    while (message->type() == MessageType::DICTIONARY_BATCH) {
-      RETURN_NOT_OK(UpdateDictionaries(*message, &dictionary_memo_, options_));
-      ARROW_ASSIGN_OR_RAISE(message, message_reader_->ReadNextMessage());
-    }
-
     CHECK_HAS_BODY(*message);
     ARROW_ASSIGN_OR_RAISE(auto reader, Buffer::GetReader(message->body()));
     return ReadRecordBatchInternal(*message->metadata(), schema_, field_inclusion_mask_,
```

It touches these lines, which are the ones to avoid:

- `cpp/src/arrow/array/validate.cc` lines 219-219
- `cpp/src/arrow/array/validate.cc` lines 231-231
- `cpp/src/arrow/array/validate.cc` lines 243-244
- `cpp/src/arrow/ipc/reader.cc` lines 686-687
- `cpp/src/arrow/ipc/reader.cc` lines 748-753

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Heap-buffer-overflow READ {*}
- Instrumentation: asan
- Entry point: arrow-ipc-file-fuzz

```
======================= INFO =========================
This binary is built for AFL-fuzz.
To run the target function on individual input(s) execute this:
  /out/arrow-ipc-file-fuzz < INPUT_FILE
or
  /out/arrow-ipc-file-fuzz INPUT_FILE1 [INPUT_FILE2 ... ]
To fuzz with afl-fuzz execute this:
  afl-fuzz [afl-flags] /out/arrow-ipc-file-fuzz [-N]
afl-fuzz will run N iterations before re-spawning the process (default: 1000)
======================================================
Reading 1862 bytes from /tmp/poc
=================================================================
[1m[31m==7==ERROR: AddressSanitizer: heap-buffer-overflow on address 0x60a000000080 at pc 0x00000058c9c7 bp 0x7ffc6b945830 sp 0x7ffc6b944ff8
[1m[0m[1m[34mREAD of size 385875977 at 0x60a000000080 thread T0[1m[0m
SCARINESS: 26 (multi-byte-read-heap-buffer-overflow)
    #0 0x58c9c6 in __asan_memcpy /src/llvm-project/compiler-rt/lib/asan/asan_interceptors_memintrinsics.cpp:22:3
    #1 0x7ae630 in arrow::ConcatenateBuffers(std::__1::vector<std::__1::shared_ptr<arrow::Buffer>, std::__1::allocator<std::__1::shared_ptr<arrow::Buffer> > > const&, arrow::MemoryPool*) /src/arrow/cpp/src/arrow/buffer.cc:261:5
    #2 0x7336ae in arrow::ConcatenateImpl::Visit(arrow::BinaryType const&) /src/arrow/cpp/src/arrow/array/concatenate.cc:199:12
    #3 0x731b2b in arrow::Status arrow::VisitTypeInline<arrow::ConcatenateImpl>(arrow::DataType const&, arrow::ConcatenateImpl*) /src/arrow/cpp/src/arrow/visitor_inline.h:88:5
    #4 0x72cf1b in arrow::ConcatenateImpl::Concatenate(std::__1::shared_ptr<arrow::ArrayData>*) && /src/arrow/cpp/src/arrow/array/concatenate.cc:179:5
    #5 0x728e5e in arrow::Concatenate(std::__1::vector<std::__1::shared_ptr<arrow::Array>, std::__1::allocator<std::__1::shared_ptr<arrow::Array> > > const&, arrow::MemoryPool*) /src/arrow/cpp/src/arrow/array/concatenate.cc:388:3
    #6 0x15bd6fb in arrow::ipc::DictionaryMemo::AddDictionaryDelta(long, std::__1::shared_ptr<arrow::Array> const&, arrow::MemoryPool*) /src/arrow/cpp/src/arrow/ipc/dictionary.cc:152:3
    #7 0x5e784c in arrow::ipc::ReadDictionary(arrow::Buffer const&, arrow::ipc::DictionaryMemo*, arrow::ipc::IpcReadOptions const&, arrow::io::RandomAccessFile*) /src/arrow/cpp/src/arrow/ipc/reader.cc:688:29
    #8 0x6bafb0 in arrow::ipc::RecordBatchFileReaderImpl::ReadDictionaries() /src/arrow/cpp/src/arrow/ipc/reader.cc:926:7
    #9 0x6b6341 in arrow::ipc::RecordBatchFileReaderImpl::ReadRecordBatch(int) /src/arrow/cpp/src/arrow/ipc/reader.cc:861:7
    #10 0x643d08 in arrow::ipc::internal::FuzzIpcFile(unsigned char const*, long) /src/arrow/cpp/src/arrow/ipc/reader.cc:1634:5
    #11 0x5c16d9 in LLVMFuzzerTestOneInput /src/arrow/cpp/src/arrow/ipc/file_fuzz.cc:25:17
    #12 0x5bfd6e in ExecuteFilesOnyByOne /src/libfuzzer/afl/afl_driver.cpp:217:5
    #13 0x5bfd6e in main /src/libfuzzer/afl/afl_driver.cpp:254:12
    #14 0x7efd44f9682f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)
    #15 0x515258 in _start (/out/arrow-ipc-file-fuzz+0x515258)

DEDUP_TOKEN: __asan_memcpy--arrow::ConcatenateBuffers(std::__1::vector<std::__1::shared_ptr<arrow::Buffer>, std::__1::allocator<std::__1::shared_ptr<arrow::Buffer> > > const&, arrow::MemoryPool*)--arrow::ConcatenateImpl::Visit(arrow::BinaryType const&)
[1m[32m0x60a000000080 is located 0 bytes to the right of 64-byte region [0x60a000000040,0x60a000000080)
[1m[0m[1m[35mallocated by thread T0 here:[1m[0m
    #0 0x58e017 in posix_memalign /src/llvm-project/compiler-rt/lib/asan/asan_malloc_linux.cpp:226:3
    #1 0x7c4557 in AllocateAligned /src/arrow/cpp/src/arrow/memory_pool.cc:113:24
    #2 0x7c4557 in arrow::BaseMemoryPoolImpl<arrow::(anonymous namespace)::SystemAllocator>::Allocate(long, unsigned char**) /src/arrow/cpp/src/arrow/memory_pool.cc:295:5
    #3 0x7b0c1b in arrow::PoolBuffer::Reserve(long) /src/arrow/cpp/src/arrow/buffer.cc:158:9
    #4 0x7b025e in arrow::PoolBuffer::Resize(long, bool) /src/arrow/cpp/src/arrow/buffer.cc:182:7
    #5 0x7aa2c8 in ResizePoolBuffer<std::__1::unique_ptr<arrow::Buffer, std::__1::default_delete<arrow::Buffer> >, std::__1::unique_ptr<arrow::PoolBuffer, std::__1::default_delete<arrow::PoolBuffer> > > /src/arrow/cpp/src/arrow/buffer.cc:221:3
    #6 0x7aa2c8 in arrow::AllocateBuffer(long, arrow::MemoryPool*) /src/arrow/cpp/src/arrow/buffer.cc:229:10
    #7 0x16056fa in arrow::ipc::MessageDecoder::MessageDecoderImpl::ConsumeBodyChunks() /src/arrow/cpp/src/arrow/ipc/message.cc:722:7
    #8 0x15fbd9c in arrow::ipc::MessageDecoder::MessageDecoderImpl::ConsumeChunks() /src/arrow/cpp/src/arrow/ipc/message.cc:569:11
    #9 0x15f8579 in arrow::ipc::MessageDecoder::MessageDecoderImpl::ConsumeBuffer(std::__1::shared_ptr<arrow::Buffer>) /src/arrow/cpp/src/arrow/ipc/message.cc:544:12
    #10 0x15e40b9 in Consume /src/arrow/cpp/src/arrow/ipc/message.cc:811:17
    #11 0x15e40b9 in arrow::ipc::ReadMessage(long, int, arrow::io::RandomAccessFile*) /src/arrow/cpp/src/arrow/ipc/message.cc:307:7
    #12 0x6bcb25 in arrow::ipc::RecordBatchFileReaderImpl::ReadMessageFromBlock(arrow::ipc::internal::FileBlock const&, std::__1::unique_ptr<arrow::ipc::Message, std::__1::default_delete<arrow::ipc::Message> >*) /src/arrow/cpp/src/arrow/ipc/reader.cc:915:12
    #13 0x6ba541 in arrow::ipc::RecordBatchFileReaderImpl::ReadDictionaries() /src/arrow/cpp/src/arrow/ipc/reader.cc:922:7
    #14 0x6b6341 in arrow::ipc::RecordBatchFileReaderImpl::ReadRecordBatch(int) /src/arrow/cpp/src/arrow/ipc/reader.cc:861:7
    #15 0x643d08 in arrow::ipc::internal::FuzzIpcFile(unsigned char const*, long) /src/arrow/cpp/src/arrow/ipc/reader.cc:1634:5
    #16 0x5c16d9 in LLVMFuzzerTestOneInput /src/arrow/cpp/src/arrow/ipc/file_fuzz.cc:25:17
    #17 0x5bfd6e in ExecuteFilesOnyByOne /src/libfuzzer/afl/afl_driver.cpp:217:5
    #18 0x5bfd6e in main /src/libfuzzer/afl/afl_driver.cpp:254:12
    #19 0x7efd44f9682f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)

DEDUP_TOKEN: posix_memalign--AllocateAligned--arrow::BaseMemoryPoolImpl<arrow::(anonymous namespace)::SystemAllocator>::Allocate(long, unsigned char**)
SUMMARY: AddressSanitizer: heap-buffer-overflow /src/llvm-project/compiler-rt/lib/asan/asan_interceptors_memintrinsics.cpp:22:3 in __asan_memcpy
Shadow bytes around the buggy address:
  0x0c147fff7fc0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c147fff7fd0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c147fff7fe0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c147fff7ff0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c147fff8000: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
=>0x0c147fff8010:[[1m[31mfa[1m[0m][1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c147fff8020: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c147fff8030: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c147fff8040: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c147fff8050: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c147fff8060: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
Shadow byte legend (one shadow byte represents 8 application bytes):
  Addressable:           [1m[0m00[1m[0m
  Partially addressable: [1m[0m01[1m[0m [1m[0m02[1m[0m [1m[0m03[1m[0m [1m[0m04[1m[0m [1m[0m05[1m[0m [1m[0m06[1m[0m [1m[0m07[1m[0m
  Heap left redzone:       [1m[31mfa[1m[0m
  Freed heap region:       [1m[35mfd[1m[0m
  Stack left redzone:      [1m[31mf1[1m[0m
  Stack mid redzone:       [1m[31mf2[1m[0m
  Stack right redzone:     [1m[31mf3[1m[0m
  Stack after return:      [1m[35mf5[1m[0m
  Stack use after scope:   [1m[35mf8[1m[0m
  Global redzone:          [1m[31mf9[1m[0m
  Global init order:       [1m[36mf6[1m[0m
  Poisoned by user:        [1m[34mf7[1m[0m
  Container overflow:      [1m[34mfc[1m[0m
  Array cookie:            [1m[31mac[1m[0m
  Intra object redzone:    [1m[33mbb[1m[0m
  ASan internal:           [1m[33mfe[1m[0m
  Left alloca redzone:     [1m[34mca[1m[0m
  Right alloca redzone:    [1m[34mcb[1m[0m
  Shadow gap:              [1m[0mcc[1m[0m
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
