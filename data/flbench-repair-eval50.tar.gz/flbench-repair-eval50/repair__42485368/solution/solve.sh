#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/cpp/src/arrow/array/validate.cc b/cpp/src/arrow/array/validate.cc
index f42296165..bdb8a7d22 100644
--- a/cpp/src/arrow/array/validate.cc
+++ b/cpp/src/arrow/array/validate.cc
@@ -216,7 +216,28 @@ struct ValidateArrayVisitor {
     if (array.value_data() == nullptr) {
       return Status::Invalid("value data buffer is null");
     }
-    return ValidateOffsets(array);
+    RETURN_NOT_OK(ValidateOffsets(array));
+
+    if (array.length() > 0) {
+      const auto first_offset = array.value_offset(0);
+      const auto last_offset = array.value_offset(array.length());
+      if (first_offset < 0 || last_offset < 0) {
+        return Status::Invalid("Negative offsets in binary array");
+      }
+      const auto data_extent = last_offset - first_offset;
+      const auto values_length = array.value_data()->size();
+      if (values_length < data_extent) {
+        return Status::Invalid("Length spanned by binary offsets (", data_extent,
+                               ") larger than values array (size ", values_length, ")");
+      }
+      if (first_offset > values_length || last_offset > values_length) {
+        return Status::Invalid("First or last binary offset out of bounds");
+      }
+      if (first_offset > last_offset) {
+        return Status::Invalid("First offset larger than last offset in binary array");
+      }
+    }
+    return Status::OK();
   }
 
   template <typename ListArrayType>
@@ -228,7 +249,6 @@ struct ValidateArrayVisitor {
     if (array.length() > 0) {
       const auto first_offset = array.value_offset(0);
       const auto last_offset = array.value_offset(array.length());
-      // This early test avoids undefined behaviour when computing `data_extent`
       if (first_offset < 0 || last_offset < 0) {
         return Status::Invalid("Negative offsets in list array");
       }
@@ -241,6 +261,12 @@ struct ValidateArrayVisitor {
         return Status::Invalid("Length spanned by list offsets (", data_extent,
                                ") larger than values array (length ", values_length, ")");
       }
+      if (first_offset > values_length || last_offset > values_length) {
+        return Status::Invalid("First or last list offset out of bounds");
+      }
+      if (first_offset > last_offset) {
+        return Status::Invalid("First offset larger than last offset in list array");
+      }
     }
 
     const Status child_valid = ValidateArray(*array.values());
diff --git a/cpp/src/arrow/ipc/reader.cc b/cpp/src/arrow/ipc/reader.cc
index 20cab041e..8d5942d8e 100644
--- a/cpp/src/arrow/ipc/reader.cc
+++ b/cpp/src/arrow/ipc/reader.cc
@@ -684,6 +684,7 @@ Status ReadDictionary(const Buffer& metadata, DictionaryMemo* dictionary_memo,
     return Status::Invalid("Dictionary record batch must only contain one field");
   }
   auto dictionary = batch->column(0);
+  RETURN_NOT_OK(dictionary->Validate());
   if (dictionary_batch->isDelta()) {
     return dictionary_memo->AddDictionaryDelta(id, dictionary, options.memory_pool);
   }
@@ -739,18 +740,18 @@ class RecordBatchStreamReaderImpl : public RecordBatchStreamReader {
 
     std::unique_ptr<Message> message;
     ARROW_ASSIGN_OR_RAISE(message, message_reader_->ReadNextMessage());
+
+    while (message != nullptr && message->type() == MessageType::DICTIONARY_BATCH) {
+      RETURN_NOT_OK(UpdateDictionaries(*message, &dictionary_memo_, options_));
+      ARROW_ASSIGN_OR_RAISE(message, message_reader_->ReadNextMessage());
+    }
+
     if (message == nullptr) {
       // End of stream
       *batch = nullptr;
       return Status::OK();
     }
 
-    // continue to read other dictionaries, if any
-    while (message->type() == MessageType::DICTIONARY_BATCH) {
-      RETURN_NOT_OK(UpdateDictionaries(*message, &dictionary_memo_, options_));
-      ARROW_ASSIGN_OR_RAISE(message, message_reader_->ReadNextMessage());
-    }
-
     CHECK_HAS_BODY(*message);
     ARROW_ASSIGN_OR_RAISE(auto reader, Buffer::GetReader(message->body()));
     return ReadRecordBatchInternal(*message->metadata(), schema_, field_inclusion_mask_,

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42485368: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
