#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/media_tools/mpegts.c b/src/media_tools/mpegts.c
index b22fdbecd..cac6564ee 100644
--- a/src/media_tools/mpegts.c
+++ b/src/media_tools/mpegts.c
@@ -499,6 +499,11 @@ static void gf_m2ts_section_complete(GF_M2TS_Demuxer *ts, GF_M2TS_SectionFilter
 		if (section_valid) {
 			GF_M2TS_Section *section;
 
+			if (sec->length <= section_start) {
+				GF_LOG(GF_LOG_ERROR, GF_LOG_CONTAINER, ("[MPEG-2 TS] section length invalid\n"));
+				return;
+			}
+
 			GF_SAFEALLOC(section, GF_M2TS_Section);
 			if (!section) {
 				GF_LOG(GF_LOG_ERROR, GF_LOG_CONTAINER, ("[MPEG-2 TS] Fail to create section\n"));
@@ -1151,7 +1156,7 @@ static void gf_m2ts_process_pmt(GF_M2TS_Demuxer *ts, GF_M2TS_SECTION_ES *pmt, GF
 		len = (u32) data[5];
 		while (info_length > first_loop_len) {
 			if (tag == GF_M2TS_MPEG4_IOD_DESCRIPTOR) {
-				if ((len>2) && (len - 2 <= info_length)) {
+				if ((len>2) && (len - 2 <= info_length) && (data_size>8) && (data_size-8 > (u32)len-2)) {
 					u32 size;
 					GF_BitStream *iod_bs;
 					iod_bs = gf_bs_new((char *)data+8, len-2, GF_BITSTREAM_READ);
@@ -1199,7 +1204,7 @@ static void gf_m2ts_process_pmt(GF_M2TS_Demuxer *ts, GF_M2TS_SECTION_ES *pmt, GF
 					/* don't know what to do with it for now, delete */
 					gf_m2ts_metadata_pointer_descriptor_del(metapd);
 				}
-			} else if(tag == GF_M2TS_REGISTRATION_DESCRIPTOR && len >= 4) {
+			} else if(tag == GF_M2TS_REGISTRATION_DESCRIPTOR && len >= 4 && data_size>9) {
 				u32 reg_desc_format = GF_4CC(data[6], data[7], data[8], data[9]);
 				GF_LOG(GF_LOG_INFO, GF_LOG_CONTAINER, ("[MPEG-2 TS] Registration descriptor with format_identifier \"%s\"\n", gf_4cc_to_str(reg_desc_format)));
 			} else {
diff --git a/src/odf/slc.c b/src/odf/slc.c
index 4563bb2b8..bbdd9c53e 100644
--- a/src/odf/slc.c
+++ b/src/odf/slc.c
@@ -166,6 +166,8 @@ GF_Err gf_odf_read_slc(GF_BitStream *bs, GF_SLConfig *sl, u32 DescSize)
 		e = gf_odf_slc_set_pref(sl);
 		if (e) return e;
 	} else {
+		if (gf_bs_available(bs) < 15) return GF_ODF_INVALID_DESCRIPTOR;
+
 		sl->useAccessUnitStartFlag = gf_bs_read_int(bs, 1);
 		sl->useAccessUnitEndFlag = gf_bs_read_int(bs, 1);
 		sl->useRandomAccessPointFlag = gf_bs_read_int(bs, 1);

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 368490563: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
