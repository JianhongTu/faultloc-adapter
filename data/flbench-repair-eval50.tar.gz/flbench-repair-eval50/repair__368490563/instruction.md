## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/src/media_tools/mpegts.c b/src/media_tools/mpegts.c
index b22fdbecd..cac6564ee 100644
--- a/src/media_tools/mpegts.c
+++ b/src/media_tools/mpegts.c
@@ -499,6 +499,11 @@ static void gf_m2ts_section_complete(GF_M2TS_Demuxer *ts, GF_M2TS_SectionFilter
 		if (section_valid) {
 			GF_M2TS_Section *section;
 
+			if (sec->length <= section_start) {
+				GF_LOG(GF_LOG_ERROR, GF_LOG_CONTAINER, ("[MPEG-2 TS] section length invalid\n"));
+				return;
+			}
+
 			GF_SAFEALLOC(section, GF_M2TS_Section);
 			if (!section) {
 				GF_LOG(GF_LOG_ERROR, GF_LOG_CONTAINER, ("[MPEG-2 TS] Fail to create section\n"));
@@ -1151,7 +1156,7 @@ static void gf_m2ts_process_pmt(GF_M2TS_Demuxer *ts, GF_M2TS_SECTION_ES *pmt, GF
 		len = (u32) data[5];
 		while (info_length > first_loop_len) {
 			if (tag == GF_M2TS_MPEG4_IOD_DESCRIPTOR) {
-				if ((len>2) && (len - 2 <= info_length)) {
+				if ((len>2) && (len - 2 <= info_length) && (data_size>8) && (data_size-8 > (u32)len-2)) {
 					u32 size;
 					GF_BitStream *iod_bs;
 					iod_bs = gf_bs_new((char *)data+8, len-2, GF_BITSTREAM_READ);
@@ -1199,7 +1204,7 @@ static void gf_m2ts_process_pmt(GF_M2TS_Demuxer *ts, GF_M2TS_SECTION_ES *pmt, GF
 					/* don't know what to do with it for now, delete */
 					gf_m2ts_metadata_pointer_descriptor_del(metapd);
 				}
-			} else if(tag == GF_M2TS_REGISTRATION_DESCRIPTOR && len >= 4) {
+			} else if(tag == GF_M2TS_REGISTRATION_DESCRIPTOR && len >= 4 && data_size>9) {
 				u32 reg_desc_format = GF_4CC(data[6], data[7], data[8], data[9]);
 				GF_LOG(GF_LOG_INFO, GF_LOG_CONTAINER, ("[MPEG-2 TS] Registration descriptor with format_identifier \"%s\"\n", gf_4cc_to_str(reg_desc_format)));
 			} else {
diff --git a/src/odf/slc.c b/src/odf/slc.c
index 4563bb2b8..bbdd9c53e 100644
--- a/src/odf/slc.c
+++ b/src/odf/slc.c
@@ -166,6 +166,8 @@ GF_Err gf_odf_read_slc(GF_BitStream *bs, GF_SLConfig *sl, u32 DescSize)
 		e = gf_odf_slc_set_pref(sl);
 		if (e) return e;
 	} else {
+		if (gf_bs_available(bs) < 15) return GF_ODF_INVALID_DESCRIPTOR;
+
 		sl->useAccessUnitStartFlag = gf_bs_read_int(bs, 1);
 		sl->useAccessUnitEndFlag = gf_bs_read_int(bs, 1);
 		sl->useRandomAccessPointFlag = gf_bs_read_int(bs, 1);
```

It touches these lines, which are the ones to avoid:

- `src/media_tools/mpegts.c` lines 501-502
- `src/media_tools/mpegts.c` lines 1154-1154
- `src/media_tools/mpegts.c` lines 1202-1202
- `src/odf/slc.c` lines 168-169

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: UNKNOWN READ
- Instrumentation: ubsan
- Entry point: fuzz_m2ts_probe

```
INFO: Running with entropic power schedule (0xFF, 100).
INFO: Seed: 2743943008
INFO: Loaded 1 modules   (322634 inline 8-bit counters): 322634 [0x564fb54e66c0, 0x564fb553530a),
INFO: Loaded 1 PC tables (322634 PCs): 322634 [0x564fb5535310,0x564fb5a217b0),
/out/fuzz_m2ts_probe: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
UndefinedBehaviorSanitizer:DEADLYSIGNAL
[1m[31m==7==ERROR: UndefinedBehaviorSanitizer: SEGV on unknown address 0x5650d6e51b76 (pc 0x7fc7c4a1cb38 bp 0x7ffdb28521f0 sp 0x7ffdb2852158 T7)
[1m[0m==7==The signal is caused by a READ memory access.
    #0 0x7fc7c4a1cb38  (/lib/x86_64-linux-gnu/libc.so.6+0x18bb38) (BuildId: 0702430aef5fa3dda43986563e9ffcc47efbd75e)
    #1 0x564fb45059e8 in gf_m2ts_section_complete /src/gpac/src/media_tools/mpegts.c:509:4
    #2 0x564fb4504772 in gf_m2ts_gather_section /src/gpac/src/media_tools/mpegts.c:705:2
    #3 0x564fb44fd3eb in gf_m2ts_process_packet /src/gpac/src/media_tools/mpegts.c
    #4 0x564fb44fcaec in gf_m2ts_process_data /src/gpac/src/media_tools/mpegts.c:2814:18
    #5 0x564fb45024f8 in gf_m2ts_probe_buffer /src/gpac/src/media_tools/mpegts.c:3200:6
    #6 0x564fb450248f in gf_m2ts_probe_file /src/gpac/src/media_tools/mpegts.c:3246:9
    #7 0x564fb44fac12 in LLVMFuzzerTestOneInput /src/gpac/testsuite/oss-fuzzers/fuzz_m2ts_probe.c:16:3
    #8 0x564fb445d560 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerLoop.cpp:614:13
    #9 0x564fb4447cf4 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:327:6
    #10 0x564fb444d78a in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:862:9
    #11 0x564fb4479b82 in main /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerMain.cpp:20:10
    #12 0x7fc7c48b5082 in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x24082) (BuildId: 0702430aef5fa3dda43986563e9ffcc47efbd75e)
    #13 0x564fb443e7cd in _start (/out/fuzz_m2ts_probe+0xaf47cd)

DEDUP_TOKEN: gf_m2ts_section_complete--gf_m2ts_gather_section
UndefinedBehaviorSanitizer can not provide additional info.
SUMMARY: UndefinedBehaviorSanitizer: SEGV (/lib/x86_64-linux-gnu/libc.so.6+0x18bb38) (BuildId: 0702430aef5fa3dda43986563e9ffcc47efbd75e)
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
