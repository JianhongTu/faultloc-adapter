#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/librawspeed/decoders/ArwDecoder.cpp b/src/librawspeed/decoders/ArwDecoder.cpp
index 4c9ae009..c48d5084 100644
--- a/src/librawspeed/decoders/ArwDecoder.cpp
+++ b/src/librawspeed/decoders/ArwDecoder.cpp
@@ -189,7 +189,8 @@ RawImage ArwDecoder::decodeRawInternal() {
   if (arw1)
     height += 8;
 
-  if (width == 0 || height == 0 || width > 8000 || height > 5320)
+  if (width == 0 || height == 0 || height % 2 != 0 || width > 8000 ||
+      height > 5320)
     ThrowRDE("Unexpected image dimensions found: (%u; %u)", width, height);
 
   mRaw->dim = iPoint2D(width, height);

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42501289: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
