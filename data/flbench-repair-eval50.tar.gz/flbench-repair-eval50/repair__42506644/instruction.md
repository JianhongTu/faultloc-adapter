## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/src/ua_types_encoding_binary.c b/src/ua_types_encoding_binary.c
index 1b8abdae0..9294ed988 100644
--- a/src/ua_types_encoding_binary.c
+++ b/src/ua_types_encoding_binary.c
@@ -943,7 +943,7 @@ ExtensionObject_decodeBinaryContent(UA_ExtensionObject *dst, const UA_NodeId *ty
     /* Unknown type, just take the binary content */
     if(!type) {
         dst->encoding = UA_EXTENSIONOBJECT_ENCODED_BYTESTRING;
-        dst->content.encoded.typeId = *typeId;
+        UA_NodeId_copy(typeId, &dst->content.encoded.typeId);
         return ByteString_decodeBinary(&dst->content.encoded.body);
     }
 
```

It touches these lines, which are the ones to avoid:

- `src/ua_types_encoding_binary.c` lines 946-946

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Heap-use-after-free READ {*}
- Instrumentation: asan
- Entry point: fuzz_binary_decode

```
INFO: Seed: 1287737633
INFO: Loaded 1 modules   (3826 inline 8-bit counters): 3826 [0x9ed0c8, 0x9edfba),
INFO: Loaded 1 PC tables (3826 PCs): 3826 [0x9edfc0,0x9fcee0),
/out/fuzz_binary_decode: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
=================================================================
[1m[31m==7==ERROR: AddressSanitizer: heap-use-after-free on address 0x612000000940 at pc 0x000000511c2d bp 0x7fffffffd890 sp 0x7fffffffd040
[1m[0m[1m[34mREAD of size 258 at 0x612000000940 thread T0[1m[0m
SCARINESS: 54 (multi-byte-read-heap-use-after-free)
    #0 0x511c2c in __asan_memcpy /src/llvm/projects/compiler-rt/lib/asan/asan_interceptors_memintrinsics.cc:23
    #1 0x5519ee in UA_Array_copy /src/open62541/src/ua_types.c:1036:9
    #2 0x55549b in copy_noInit /src/open62541/src/ua_types.c:913:23
    #3 0x55610d in UA_copy /src/open62541/src/ua_types.c:928:28
    #4 0x55610d in UA_String_copy /work/open62541/src_generated/ua_types_generated_handling.h:308
    #5 0x55610d in NodeId_copy /src/open62541/src/ua_types.c:214
    #6 0x5567eb in ExtensionObject_copy /src/open62541/src/ua_types.c:352:18
    #7 0x55554f in copy_noInit /src/open62541/src/ua_types.c:903:23
    #8 0x5518ab in UA_copy /src/open62541/src/ua_types.c:928:28
    #9 0x5518ab in UA_Array_copy /src/open62541/src/ua_types.c:1044
    #10 0x556cdc in Variant_copy /src/open62541/src/ua_types.c:391:28
    #11 0x55554f in copy_noInit /src/open62541/src/ua_types.c:903:23
    #12 0x5518ab in UA_copy /src/open62541/src/ua_types.c:928:28
    #13 0x5518ab in UA_Array_copy /src/open62541/src/ua_types.c:1044
    #14 0x55549b in copy_noInit /src/open62541/src/ua_types.c:913:23
    #15 0x5518ab in UA_copy /src/open62541/src/ua_types.c:928:28
    #16 0x5518ab in UA_Array_copy /src/open62541/src/ua_types.c:1044
    #17 0x55554f in copy_noInit /src/open62541/src/ua_types.c:903:23
    #18 0x551570 in UA_copy /src/open62541/src/ua_types.c:928:28
    #19 0x54e5e3 in tortureEncoding(unsigned char const*, unsigned long, unsigned long*) /src/open62541/tests/fuzz/fuzz_binary_decode.cc:37:9
    #20 0x54e5e3 in LLVMFuzzerTestOneInput /src/open62541/tests/fuzz/fuzz_binary_decode.cc:100
    #21 0x649090 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/libfuzzer/FuzzerLoop.cpp:512:13
    #22 0x6274a5 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/libfuzzer/FuzzerDriver.cpp:273:6
    #23 0x632ca1 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/libfuzzer/FuzzerDriver.cpp:692:9
    #24 0x626b48 in main /src/libfuzzer/FuzzerMain.cpp:20:10
    #25 0x7ffff6ee582f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)
    #26 0x4500b8 in _start (/out/fuzz_binary_decode+0x4500b8)

DEDUP_TOKEN: __asan_memcpy--UA_Array_copy--copy_noInit
[1m[32m0x612000000940 is located 0 bytes inside of 258-byte region [0x612000000940,0x612000000a42)
[1m[0m[1m[35mfreed by thread T0 here:[1m[0m
    #0 0x512b08 in __interceptor_cfree.localalias.0 /src/llvm/projects/compiler-rt/lib/asan/asan_malloc_linux.cc:76
    #1 0x555c0b in deleteMembers_noInit /src/open62541/src/ua_types.c:979:13
    #2 0x55573f in UA_deleteMembers /src/open62541/src/ua_types.c:993:5
    #3 0x55d88a in UA_NodeId_deleteMembers /work/open62541/src_generated/ua_types_generated_handling.h:441:5
    #4 0x55d88a in ExtensionObject_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:977
    #5 0x55ef78 in Variant_decodeBinaryUnwrapExtensionObject /src/open62541/src/ua_types_encoding_binary.c:1128:12
    #6 0x55ef78 in Variant_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:1163
    #7 0x563185 in Array_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:569:19
    #8 0x55d3d2 in UA_decodeBinaryInternal /src/open62541/src/ua_types_encoding_binary.c:1509:20
    #9 0x55ddd2 in ExtensionObject_decodeBinaryContent /src/open62541/src/ua_types_encoding_binary.c:962:12
    #10 0x55ddd2 in ExtensionObject_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:982
    #11 0x55d471 in UA_decodeBinaryInternal /src/open62541/src/ua_types_encoding_binary.c:1503:20
    #12 0x55fa4d in UA_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:1538:18
    #13 0x54e59d in tortureEncoding(unsigned char const*, unsigned long, unsigned long*) /src/open62541/tests/fuzz/fuzz_binary_decode.cc:32:25
    #14 0x54e59d in LLVMFuzzerTestOneInput /src/open62541/tests/fuzz/fuzz_binary_decode.cc:100
    #15 0x649090 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/libfuzzer/FuzzerLoop.cpp:512:13
    #16 0x6274a5 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/libfuzzer/FuzzerDriver.cpp:273:6
    #17 0x632ca1 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/libfuzzer/FuzzerDriver.cpp:692:9
    #18 0x626b48 in main /src/libfuzzer/FuzzerMain.cpp:20:10
    #19 0x7ffff6ee582f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)

DEDUP_TOKEN: __interceptor_cfree.localalias.0--deleteMembers_noInit--UA_deleteMembers
[1m[35mpreviously allocated by thread T0 here:[1m[0m
    #0 0x512ee0 in calloc /src/llvm/projects/compiler-rt/lib/asan/asan_malloc_linux.cc:97
    #1 0x56301a in Array_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:551:12
    #2 0x55c9c6 in String_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:594:12
    #3 0x55c9c6 in ByteString_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:604
    #4 0x55c9c6 in NodeId_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:747
    #5 0x55d7f4 in ExtensionObject_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:974:18
    #6 0x55ef78 in Variant_decodeBinaryUnwrapExtensionObject /src/open62541/src/ua_types_encoding_binary.c:1128:12
    #7 0x55ef78 in Variant_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:1163
    #8 0x563185 in Array_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:569:19
    #9 0x55d3d2 in UA_decodeBinaryInternal /src/open62541/src/ua_types_encoding_binary.c:1509:20
    #10 0x55ddd2 in ExtensionObject_decodeBinaryContent /src/open62541/src/ua_types_encoding_binary.c:962:12
    #11 0x55ddd2 in ExtensionObject_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:982
    #12 0x55d471 in UA_decodeBinaryInternal /src/open62541/src/ua_types_encoding_binary.c:1503:20
    #13 0x55fa4d in UA_decodeBinary /src/open62541/src/ua_types_encoding_binary.c:1538:18
    #14 0x54e59d in tortureEncoding(unsigned char const*, unsigned long, unsigned long*) /src/open62541/tests/fuzz/fuzz_binary_decode.cc:32:25
    #15 0x54e59d in LLVMFuzzerTestOneInput /src/open62541/tests/fuzz/fuzz_binary_decode.cc:100
    #16 0x649090 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/libfuzzer/FuzzerLoop.cpp:512:13
    #17 0x6274a5 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/libfuzzer/FuzzerDriver.cpp:273:6
    #18 0x632ca1 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/libfuzzer/FuzzerDriver.cpp:692:9
    #19 0x626b48 in main /src/libfuzzer/FuzzerMain.cpp:20:10
    #20 0x7ffff6ee582f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)

DEDUP_TOKEN: calloc--Array_decodeBinary--String_decodeBinary
SUMMARY: AddressSanitizer: heap-use-after-free /src/llvm/projects/compiler-rt/lib/asan/asan_interceptors_memintrinsics.cc:23 in __asan_memcpy
Shadow bytes around the buggy address:
  0x0c247fff80d0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c247fff80e0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m06[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c247fff80f0: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c247fff8100: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c247fff8110: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
=>0x0c247fff8120: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m[[1m[35mfd[1m[0m][1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c247fff8130: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c247fff8140: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c247fff8150: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c247fff8160: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c247fff8170: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m02[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
Shadow byte legend (one shadow byte represents 8 application bytes):
  Addressable:           [1m[0m00[1m[0m
  Partially addressable: [1m[0m01[1m[0m [1m[0m02[1m[0m [1m[0m03[1m[0m [1m[0m04[1m[0m [1m[0m05[1m[0m [1m[0m06[1m[0m [1m[0m07[1m[0m
  Heap left redzone:       [1m[31mfa[1m[0m
  Freed heap region:       [1m[35mfd[1m[0m
  Stack left redzone:      [1m[31mf1[1m[0m
  Stack mid redzone:       [1m[31mf2[1m[0m
  Stack right redzone:     [1m[31mf3[1m[0m
  Stack after return:      [1m[35mf5[1m[0m
  Stack use after scope:   [1m[35mf8[1m[0m
  Global redzone:          [1m[31mf9[1m[0m
  Global init order:       [1m[36mf6[1m[0m
  Poisoned by user:        [1m[34mf7[1m[0m
  Container overflow:      [1m[34mfc[1m[0m
  Array cookie:            [1m[31mac[1m[0m
  Intra object redzone:    [1m[33mbb[1m[0m
  ASan internal:           [1m[33mfe[1m[0m
  Left alloca redzone:     [1m[34mca[1m[0m
  Right alloca redzone:    [1m[34mcb[1m[0m
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
