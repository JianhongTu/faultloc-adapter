#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
From 20b8d16e4f3fa4d94b606a7f7804ee56c776768b Mon Sep 17 00:00:00 2001
From: Dan Bloomberg <dan.bloomberg@gmail.com>
Date: Sun, 25 Oct 2020 00:56:14 -0700
Subject: [PATCH] Issue 26358: graphics_fuzzer: null deref in pixFillPolygon *
 also Issue 26409 (duplicate)

---
 src/graphics.c | 8 ++++++--
 1 file changed, 6 insertions(+), 2 deletions(-)

diff --git a/src/graphics.c b/src/graphics.c
index 910574996..c2100a990 100644
--- a/src/graphics.c
+++ b/src/graphics.c
@@ -2573,10 +2573,14 @@ PIX      *pixi, *pixd;
         return (PIX *)ERROR_PTR("pixs undefined or not 1 bpp", procName, NULL);
     if (!pta)
         return (PIX *)ERROR_PTR("pta not defined", procName, NULL);
+    if (ptaGetCount(pta) < 2)
+        return (PIX *)ERROR_PTR("pta has < 2 pts", procName, NULL);
 
     pixGetDimensions(pixs, &w, &h, NULL);
-    xstart = (l_int32 *)LEPT_CALLOC(w / 2, sizeof(l_int32));
-    xend = (l_int32 *)LEPT_CALLOC(w / 2, sizeof(l_int32));
+    xstart = (l_int32 *)LEPT_CALLOC(L_MAX(1, w / 2), sizeof(l_int32));
+    xend = (l_int32 *)LEPT_CALLOC(L_MAX(1, w / 2), sizeof(l_int32));
+    if (!xstart)
+        return (PIX *)ERROR_PTR("xstart and xend not made", procName, NULL);
 
         /* Find a raster with 2 or more black runs.  The first background
          * pixel after the end of the first run is likely to be inside
PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42488057: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
