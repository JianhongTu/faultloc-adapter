## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/epan/dissectors/packet-zbee-security.c b/epan/dissectors/packet-zbee-security.c
index e9ed278c90..f9ffbb4990 100644
--- a/epan/dissectors/packet-zbee-security.c
+++ b/epan/dissectors/packet-zbee-security.c
@@ -1250,7 +1250,7 @@ void zbee_sec_add_key_to_keyring(packet_info *pinfo, const guint8 *key)
 
         if ( nwk_keyring ) {
             if ( !*nwk_keyring ||
-                    memcmp( ((key_record_t *)((GSList *)(*nwk_keyring))->data)->key, &key,
+                    memcmp( ((key_record_t *)((GSList *)(*nwk_keyring))->data)->key, key,
                         ZBEE_APS_CMD_KEY_LENGTH) ) {
                 /* Store a new or different key in the key ring */
                 key_record.frame_num = pinfo->num;
```

It touches these lines, which are the ones to avoid:

- `epan/dissectors/packet-zbee-security.c` lines 1253-1253

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Stack-buffer-overflow READ 16
- Instrumentation: asan
- Entry point: fuzzshark_ip

```
oss-fuzzshark: configured for dissector: ip
INFO: Seed: 1771126620
INFO: Loaded 1 modules   (273236 guards): 273236 [0xc109fa0, 0xc214cf0),
/out/fuzzshark_ip: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
=================================================================
[1m[31m==7==ERROR: AddressSanitizer: stack-buffer-overflow on address 0x7fda59f81428 at pc 0x0000004b77b5 bp 0x7fffc96c4450 sp 0x7fffc96c3c00
[1m[0m[1m[34mREAD of size 16 at 0x7fda59f81428 thread T0[1m[0m
SCARINESS: 41 (multi-byte-read-stack-buffer-overflow)
    #0 0x4b77b4 in __interceptor_memcmp.part.76 /src/llvm/projects/compiler-rt/lib/asan/../sanitizer_common/sanitizer_common_interceptors.inc:774
    #1 0x2109c3d in zbee_sec_add_key_to_keyring /src/wireshark/epan/dissectors/packet-zbee-security.c:1253:21
    #2 0x20fd0cc in dissect_zbee_aps_transport_key /src/wireshark/epan/dissectors/packet-zbee-aps.c:1313:5
    #3 0x20fcbee in dissect_zbee_aps_cmd /src/wireshark/epan/dissectors/packet-zbee-aps.c:1155:22
    #4 0x20fc284 in dissect_zbee_aps /src/wireshark/epan/dissectors/packet-zbee-aps.c:1090:13
    #5 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #6 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #7 0x5babba in call_dissector_with_data /src/wireshark/epan/packet.c:3011:8
    #8 0x2104212 in dissect_zbee_nwk_full /src/wireshark/epan/dissectors/packet-zbee-nwk.c:751:9
    #9 0x2101adf in dissect_zbee_nwk /src/wireshark/epan/dissectors/packet-zbee-nwk.c:781:9
    #10 0x2102b0f in dissect_zbee_nwk_heur /src/wireshark/epan/dissectors/packet-zbee-nwk.c:426:5
    #11 0x5c11c2 in dissector_try_heuristic /src/wireshark/epan/packet.c:2623:7
    #12 0x11b0837 in dissect_ieee802154_common /src/wireshark/epan/dissectors/packet-ieee802154.c:1975:21
    #13 0x11aaaf6 in dissect_ieee802154_nofcs /src/wireshark/epan/dissectors/packet-ieee802154.c:1217:5
    #14 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #15 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #16 0x5babba in call_dissector_with_data /src/wireshark/epan/packet.c:3011:8
    #17 0x1c12cd0 in dissect_scop /src/wireshark/epan/dissectors/packet-scop.c:193:13
    #18 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #19 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #20 0x5bd0e3 in dissector_try_uint_new /src/wireshark/epan/packet.c:1335:8
    #21 0x5bd698 in dissector_try_uint /src/wireshark/epan/packet.c:1359:9
    #22 0x1eca1cc in decode_udp_ports /src/wireshark/epan/dissectors/packet-udp.c:684:7
    #23 0x1ecf032 in dissect /src/wireshark/epan/dissectors/packet-udp.c:1140:5
    #24 0x1ecc49f in dissect_udplite /src/wireshark/epan/dissectors/packet-udp.c:1153:3
    #25 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #26 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #27 0x5bd0e3 in dissector_try_uint_new /src/wireshark/epan/packet.c:1335:8
    #28 0x11f6a6d in ip_try_dissect /src/wireshark/epan/dissectors/packet-ip.c:1865:7
    #29 0x11f9c73 in dissect_ip_v4 /src/wireshark/epan/dissectors/packet-ip.c:2323:10
    #30 0x11f71a1 in dissect_ip /src/wireshark/epan/dissectors/packet-ip.c:2347:5
    #31 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #32 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #33 0x5bd0e3 in dissector_try_uint_new /src/wireshark/epan/packet.c:1335:8
    #34 0x5bd698 in dissector_try_uint /src/wireshark/epan/packet.c:1359:9
    #35 0x188b8cd in dissect_ppp_common /src/wireshark/epan/dissectors/packet-ppp.c:4838:10
    #36 0x187a7f7 in dissect_ppp_raw_hdlc /src/wireshark/epan/dissectors/packet-ppp.c:6072:17
    #37 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #38 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #39 0x5bd0e3 in dissector_try_uint_new /src/wireshark/epan/packet.c:1335:8
    #40 0x5bd698 in dissector_try_uint /src/wireshark/epan/packet.c:1359:9
    #41 0xf93717 in dissect_gre /src/wireshark/epan/dissectors/packet-gre.c:513:14
    #42 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #43 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #44 0x5bd0e3 in dissector_try_uint_new /src/wireshark/epan/packet.c:1335:8
    #45 0x11f6a6d in ip_try_dissect /src/wireshark/epan/dissectors/packet-ip.c:1865:7
    #46 0x122c84d in ipv6_dissect_next /src/wireshark/epan/dissectors/packet-ipv6.c:2462:9
    #47 0x122d930 in dissect_ipv6 /src/wireshark/epan/dissectors/packet-ipv6.c:2410:5
    #48 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #49 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #50 0x5babba in call_dissector_with_data /src/wireshark/epan/packet.c:3011:8
    #51 0x11f71c3 in dissect_ip /src/wireshark/epan/dissectors/packet-ip.c:2351:5
    #52 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #53 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #54 0x5c3470 in call_all_postdissectors /src/wireshark/epan/packet.c:3351:3
    #55 0xf42a35 in dissect_frame /src/wireshark/epan/dissectors/packet-frame.c:623:5
    #56 0x5c4742 in call_dissector_through_handle /src/wireshark/epan/packet.c:690:8
    #57 0x5bd42a in call_dissector_work /src/wireshark/epan/packet.c:765:9
    #58 0x5babba in call_dissector_with_data /src/wireshark/epan/packet.c:3011:8
    #59 0x5ba393 in dissect_record /src/wireshark/epan/packet.c:573:3
    #60 0x5af695 in epan_dissect_run /src/wireshark/epan/epan.c:467:2
    #61 0x51bec7 in LLVMFuzzerTestOneInput /src/wireshark/tools/oss-fuzzshark/fuzzshark.c:298:2
    #62 0x53e630 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/libfuzzer/FuzzerLoop.cpp:463:13
    #63 0x53f946 in fuzzer::Fuzzer::TryDetectingAMemoryLeak(unsigned char const*, unsigned long, bool) /src/libfuzzer/FuzzerLoop.cpp:536:3
    #64 0x51d27d in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/libfuzzer/FuzzerDriver.cpp:274:6
    #65 0x528560 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/libfuzzer/FuzzerDriver.cpp:687:9
    #66 0x51c8e8 in main /src/libfuzzer/FuzzerMain.cpp:20:10
    #67 0x7fda5d1c582f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)
    #68 0x41e4b8 in _start (/out/fuzzshark_ip+0x41e4b8)

DEDUP_TOKEN: __interceptor_memcmp.part.76--zbee_sec_add_key_to_keyring--dissect_zbee_aps_transport_key
[1m[32mAddress 0x7fda59f81428 is located in stack of thread T0 at offset 40 in frame[1m[0m
[1m[0m    #0 0x21099ff in zbee_sec_add_key_to_keyring /src/wireshark/epan/dissectors/packet-zbee-security.c:1236

DEDUP_TOKEN: zbee_sec_add_key_to_keyring
  This frame has 2 object(s):
    [32, 40) 'key.addr'[1m[32m <== Memory access at offset 40 overflows this variable[1m[0m
    [64, 96) 'key_record' (line 1238)
HINT: this may be a false positive if your program uses some custom stack unwind mechanism or swapcontext
      (longjmp and C++ exceptions *are* supported)
SUMMARY: AddressSanitizer: stack-buffer-overflow /src/llvm/projects/compiler-rt/lib/asan/../sanitizer_common/sanitizer_common_interceptors.inc:774 in __interceptor_memcmp.part.76
Shadow bytes around the buggy address:
  0x0ffbcb3e8230: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x0ffbcb3e8240: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x0ffbcb3e8250: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x0ffbcb3e8260: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x0ffbcb3e8270: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
=>0x0ffbcb3e8280: [1m[31mf1[1m[0m [1m[31mf1[1m[0m [1m[31mf1[1m[0m [1m[31mf1[1m[0m [1m[0m00[1m[0m[[1m[31mf2[1m[0m][1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m
  0x0ffbcb3e8290: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x0ffbcb3e82a0: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x0ffbcb3e82b0: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x0ffbcb3e82c0: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x0ffbcb3e82d0: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
Shadow byte legend (one shadow byte represents 8 application bytes):
  Addressable:           [1m[0m00[1m[0m
  Partially addressable: [1m[0m01[1m[0m [1m[0m02[1m[0m [1m[0m03[1m[0m [1m[0m04[1m[0m [1m[0m05[1m[0m [1m[0m06[1m[0m [1m[0m07[1m[0m
  Heap left redzone:       [1m[31mfa[1m[0m
  Freed heap region:       [1m[35mfd[1m[0m
  Stack left redzone:      [1m[31mf1[1m[0m
  Stack mid redzone:       [1m[31mf2[1m[0m
  Stack right redzone:     [1m[31mf3[1m[0m
  Stack after return:      [1m[35mf5[1m[0m
  Stack use after scope:   [1m[35mf8[1m[0m
  Global redzone:          [1m[31mf9[1m[0m
  Global init order:       [1m[36mf6[1m[0m
  Poisoned by user:        [1m[34mf7[1m[0m
  Container overflow:      [1m[34mfc[1m[0m
  Array cookie:            [1m[31mac[1m[0m
  Intra object redzone:    [1m[33mbb[1m[0m
  ASan internal:           [1m[33mfe[1m[0m
  Left alloca redzone:     [1m[34mca[1m[0m
  Right alloca redzone:    [1m[34mcb[1m[0m
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
