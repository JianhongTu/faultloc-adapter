## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/mongoose.c b/mongoose.c
index 698af52f..ee857755 100644
--- a/mongoose.c
+++ b/mongoose.c
@@ -2176,6 +2176,11 @@ int mg_http_status(const struct mg_http_message *hm) {
   return atoi(hm->uri.ptr);
 }
 
+static bool is_hex_digit(int c) {
+  return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') ||
+         (c >= 'A' && c <= 'F');
+}
+
 // If a server sends data to the client using chunked encoding, Mongoose strips
 // off the chunking prefix (hex length and \r\n) and suffix (\r\n), appends the
 // stripped data to the body, and fires the MG_EV_HTTP_CHUNK event.  When zero
@@ -2190,7 +2195,7 @@ int mg_http_status(const struct mg_http_message *hm) {
 // pointer: we store a size_t value there.
 static bool getchunk(struct mg_str s, size_t *prefixlen, size_t *datalen) {
   size_t i = 0, n;
-  while (i < s.len && s.ptr[i] != '\r' && s.ptr[i] != '\n') i++;
+  while (i < s.len && is_hex_digit(s.ptr[i])) i++;
   n = mg_unhexn(s.ptr, i);
   // MG_INFO(("%d %d", (int) (i + n + 4), (int) s.len));
   if (s.len < i + n + 4) return false;  // Chunk not yet fully buffered
diff --git a/src/http.c b/src/http.c
index 7abe4702..2169f973 100644
--- a/src/http.c
+++ b/src/http.c
@@ -944,6 +944,11 @@ int mg_http_status(const struct mg_http_message *hm) {
   return atoi(hm->uri.ptr);
 }
 
+static bool is_hex_digit(int c) {
+  return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') ||
+         (c >= 'A' && c <= 'F');
+}
+
 // If a server sends data to the client using chunked encoding, Mongoose strips
 // off the chunking prefix (hex length and \r\n) and suffix (\r\n), appends the
 // stripped data to the body, and fires the MG_EV_HTTP_CHUNK event.  When zero
@@ -958,7 +963,7 @@ int mg_http_status(const struct mg_http_message *hm) {
 // pointer: we store a size_t value there.
 static bool getchunk(struct mg_str s, size_t *prefixlen, size_t *datalen) {
   size_t i = 0, n;
-  while (i < s.len && s.ptr[i] != '\r' && s.ptr[i] != '\n') i++;
+  while (i < s.len && is_hex_digit(s.ptr[i])) i++;
   n = mg_unhexn(s.ptr, i);
   // MG_INFO(("%d %d", (int) (i + n + 4), (int) s.len));
   if (s.len < i + n + 4) return false;  // Chunk not yet fully buffered
```

It touches these lines, which are the ones to avoid:

- `mongoose.c` lines 2178-2179
- `mongoose.c` lines 2193-2193
- `src/http.c` lines 946-947
- `src/http.c` lines 961-961

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Negative-size-param
- Instrumentation: asan
- Entry point: fuzz

```
INFO: Running with entropic power schedule (0xFF, 100).
INFO: Seed: 3012161508
INFO: Loaded 1 modules   (4084 inline 8-bit counters): 4084 [0x6580c0, 0x6590b4),
INFO: Loaded 1 PC tables (4084 PCs): 4084 [0x5fcd00,0x60cc40),
/out/fuzz: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
=================================================================
[1m[31m==6==ERROR: AddressSanitizer: negative-size-param: (size=-2)
[1m[0mSCARINESS: 10 (negative-size-param)
    #0 0x52e6ec in __asan_memmove /src/llvm-project/compiler-rt/lib/asan/asan_interceptors_memintrinsics.cpp:30:3
    #1 0x58a4fb in deliver_chunked_chunks /src/mongoose/src/http.c:998:5
    #2 0x58a4fb in http_cb(mg_connection*, int, void*, void*) /src/mongoose/src/http.c:1062:9
    #3 0x5af7b3 in LLVMFuzzerTestOneInput /src/mongoose/test/fuzz.c:112:5
    #4 0x43de23 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerLoop.cpp:611:15
    #5 0x429582 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:324:6
    #6 0x42ee2c in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:860:9
    #7 0x458362 in main /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerMain.cpp:20:10
    #8 0x7f7413813082 in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x24082) (BuildId: 1878e6b475720c7c51969e69ab2d276fae6d1dee)
    #9 0x41f74d in _start (/out/fuzz+0x41f74d)

DEDUP_TOKEN: __asan_memmove--deliver_chunked_chunks--http_cb(mg_connection*, int, void*, void*)
[1m[32m0x61d0000000b1 is located 49 bytes inside of 2048-byte region [0x61d000000080,0x61d000000880)
[1m[0m[1m[35mallocated by thread T0 here:[1m[0m
    #0 0x52f18e in __interceptor_calloc /src/llvm-project/compiler-rt/lib/asan/asan_malloc_linux.cpp:77:3
    #1 0x5792c4 in mg_iobuf_resize /src/mongoose/src/iobuf.c:29:15
    #2 0x5af684 in mg_iobuf_add /src/mongoose/src/iobuf.c:55:3
    #3 0x5af684 in LLVMFuzzerTestOneInput /src/mongoose/test/fuzz.c:111:5
    #4 0x43de23 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerLoop.cpp:611:15
    #5 0x429582 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:324:6
    #6 0x42ee2c in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:860:9
    #7 0x458362 in main /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerMain.cpp:20:10
    #8 0x7f7413813082 in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x24082) (BuildId: 1878e6b475720c7c51969e69ab2d276fae6d1dee)

DEDUP_TOKEN: __interceptor_calloc--mg_iobuf_resize--mg_iobuf_add
SUMMARY: AddressSanitizer: negative-size-param /src/llvm-project/compiler-rt/lib/asan/asan_interceptors_memintrinsics.cpp:30:3 in __asan_memmove
==6==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
