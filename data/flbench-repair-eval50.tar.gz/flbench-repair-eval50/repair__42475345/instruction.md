## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/src/hb-ot-stat-table.hh b/src/hb-ot-stat-table.hh
index 0f75cd329..eb17f19b2 100644
--- a/src/hb-ot-stat-table.hh
+++ b/src/hb-ot-stat-table.hh
@@ -186,7 +186,7 @@ struct AxisValue
   bool sanitize (hb_sanitize_context_t *c) const
   {
     TRACE_SANITIZE (this);
-    if (unlikely (c->check_struct (this)))
+    if (unlikely (!c->check_struct (this)))
       return_trace (false);
 
     switch (u.format)
```

It touches these lines, which are the ones to avoid:

- `src/hb-ot-stat-table.hh` lines 189-189

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Heap-buffer-overflow READ 2
- Instrumentation: asan
- Entry point: hb-subset-fuzzer

```
======================= INFO =========================
This binary is built for AFL-fuzz.
To run the target function on individual input(s) execute this:
  /out/hb-subset-fuzzer < INPUT_FILE
or
  /out/hb-subset-fuzzer INPUT_FILE1 [INPUT_FILE2 ... ]
To fuzz with afl-fuzz execute this:
  afl-fuzz [afl-flags] /out/hb-subset-fuzzer [-N]
afl-fuzz will run N iterations before re-spawning the process (default: 1000)
======================================================
Reading 68 bytes from /tmp/poc
=================================================================
[1m[31m==7==ERROR: AddressSanitizer: heap-buffer-overflow on address 0x6040000000fa at pc 0x0000004ce94d bp 0x7fffbea92ed0 sp 0x7fffbea92ec8
[1m[0m[1m[34mREAD of size 2 at 0x6040000000fa thread T0[1m[0m
SCARINESS: 14 (2-byte-read-heap-buffer-overflow)
    #0 0x4ce94c in BEInt<unsigned short, 2>::operator unsigned short() const /src/harfbuzz/src/./hb.hh:588:59
    #1 0x4ce7aa in OT::IntType<unsigned short, 2u>::operator unsigned int() const /src/harfbuzz/src/./hb-open-type.hh:63:40
    #2 0x5a4d54 in OT::AxisValue::sanitize(hb_sanitize_context_t*) const /src/harfbuzz/src/./hb-ot-stat-table.hh:192:13
    #3 0x5a4759 in bool OT::OffsetTo<OT::AxisValue, OT::IntType<unsigned short, 2u>, true>::sanitize<>(hb_sanitize_context_t*, void const*) const /src/harfbuzz/src/./hb-open-type.hh:338:5
    #4 0x5a4170 in bool OT::UnsizedArrayOf<OT::OffsetTo<OT::AxisValue, OT::IntType<unsigned short, 2u>, true> >::sanitize<OT::UnsizedArrayOf<OT::OffsetTo<OT::AxisValue, OT::IntType<unsigned short, 2u>, true> > const*>(hb_sanitize_context_t*, unsigned int, OT::UnsizedArrayOf<OT::OffsetTo<OT::AxisValue, OT::IntType<unsigned short, 2u>, true> > const*&&) const /src/harfbuzz/src/./hb-open-type.hh:450:11
    #5 0x5a32df in bool OT::OffsetTo<OT::UnsizedArrayOf<OT::OffsetTo<OT::AxisValue, OT::IntType<unsigned short, 2u>, true> >, OT::IntType<unsigned int, 4u>, false>::sanitize<OT::IntType<unsigned short, 2u> const&, OT::UnsizedArrayOf<OT::OffsetTo<OT::AxisValue, OT::IntType<unsigned short, 2u>, true> > const*>(hb_sanitize_context_t*, void const*, OT::IntType<unsigned short, 2u> const&, OT::UnsizedArrayOf<OT::OffsetTo<OT::AxisValue, OT::IntType<unsigned short, 2u>, true> > const*&&) const /src/harfbuzz/src/./hb-open-type.hh:338:5
    #6 0x5a2c95 in OT::STAT::sanitize(hb_sanitize_context_t*) const /src/harfbuzz/src/./hb-ot-stat-table.hh:255:5
    #7 0x5a2834 in hb_blob_t* hb_sanitize_context_t::sanitize_blob<OT::STAT>(hb_blob_t*) /src/harfbuzz/src/./hb-sanitize.hh:322:15
    #8 0x5a2674 in hb_table_lazy_loader_t<OT::STAT, 13u>::create(hb_face_t*) /src/harfbuzz/src/./hb-machinery.hh:293:37
    #9 0x5a22f3 in hb_lazy_loader_t<OT::STAT, hb_table_lazy_loader_t<OT::STAT, 13u>, hb_face_t, 13u, hb_blob_t>::get_stored() const /src/harfbuzz/src/./hb-machinery.hh:222:26
    #10 0x5a225a in hb_lazy_loader_t<OT::STAT, hb_table_lazy_loader_t<OT::STAT, 13u>, hb_face_t, 13u, hb_blob_t>::get() const /src/harfbuzz/src/./hb-machinery.hh:245:58
    #11 0x5a0832 in _nameid_closure(hb_face_t*, hb_set_t*) /src/harfbuzz/src/hb-subset-plan.cc:209:9
    #12 0x5a0353 in hb_subset_plan_create(hb_face_t*, hb_subset_input_t*) /src/harfbuzz/src/hb-subset-plan.cc:245:3
    #13 0x4c9bf6 in hb_subset /src/harfbuzz/src/hb-subset.cc:296:28
    #14 0x4c6a9d in trySubset(hb_face_t*, unsigned int const*, int, bool, bool, bool) /src/harfbuzz/./test/fuzzing/hb-subset-fuzzer.cc:28:23
    #15 0x4c67c5 in LLVMFuzzerTestOneInput /src/harfbuzz/./test/fuzzing/hb-subset-fuzzer.cc:65:3
    #16 0x4c6f2a in ExecuteFilesOnyByOne /src/libfuzzer/afl/afl_driver.cpp:216:5
    #17 0x4c6f2a in main /src/libfuzzer/afl/afl_driver.cpp:253
    #18 0x7fa30f1fc82f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)
    #19 0x41ddf8 in _start (/out/hb-subset-fuzzer+0x41ddf8)

DEDUP_TOKEN: BEInt<unsigned short, 2>::operator unsigned short() const--OT::IntType<unsigned short, 2u>::operator unsigned int() const--OT::AxisValue::sanitize(hb_sanitize_context_t*) const
[1m[32m0x6040000000fa is located 0 bytes to the right of 42-byte region [0x6040000000d0,0x6040000000fa)
[1m[0m[1m[35mallocated by thread T0 here:[1m[0m
    #0 0x494f0d in malloc /src/llvm/projects/compiler-rt/lib/asan/asan_malloc_linux.cc:145:3
    #1 0x5c452d in hb_blob_t::try_make_writable() /src/harfbuzz/src/hb-blob.cc:470:23
    #2 0x5c509e in hb_blob_get_data_writable /src/harfbuzz/src/hb-blob.cc:378:14
    #3 0x5a2885 in hb_blob_t* hb_sanitize_context_t::sanitize_blob<OT::STAT>(hb_blob_t*) /src/harfbuzz/src/./hb-sanitize.hh:341:17
    #4 0x5a2674 in hb_table_lazy_loader_t<OT::STAT, 13u>::create(hb_face_t*) /src/harfbuzz/src/./hb-machinery.hh:293:37
    #5 0x5a22f3 in hb_lazy_loader_t<OT::STAT, hb_table_lazy_loader_t<OT::STAT, 13u>, hb_face_t, 13u, hb_blob_t>::get_stored() const /src/harfbuzz/src/./hb-machinery.hh:222:26
    #6 0x5a225a in hb_lazy_loader_t<OT::STAT, hb_table_lazy_loader_t<OT::STAT, 13u>, hb_face_t, 13u, hb_blob_t>::get() const /src/harfbuzz/src/./hb-machinery.hh:245:58
    #7 0x5a0832 in _nameid_closure(hb_face_t*, hb_set_t*) /src/harfbuzz/src/hb-subset-plan.cc:209:9
    #8 0x5a0353 in hb_subset_plan_create(hb_face_t*, hb_subset_input_t*) /src/harfbuzz/src/hb-subset-plan.cc:245:3
    #9 0x4c9bf6 in hb_subset /src/harfbuzz/src/hb-subset.cc:296:28
    #10 0x4c6a9d in trySubset(hb_face_t*, unsigned int const*, int, bool, bool, bool) /src/harfbuzz/./test/fuzzing/hb-subset-fuzzer.cc:28:23
    #11 0x4c67c5 in LLVMFuzzerTestOneInput /src/harfbuzz/./test/fuzzing/hb-subset-fuzzer.cc:65:3
    #12 0x4c6f2a in ExecuteFilesOnyByOne /src/libfuzzer/afl/afl_driver.cpp:216:5
    #13 0x4c6f2a in main /src/libfuzzer/afl/afl_driver.cpp:253
    #14 0x7fa30f1fc82f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)

DEDUP_TOKEN: malloc--hb_blob_t::try_make_writable()--hb_blob_get_data_writable
SUMMARY: AddressSanitizer: heap-buffer-overflow /src/harfbuzz/src/./hb.hh:588:59 in BEInt<unsigned short, 2>::operator unsigned short() const
Shadow bytes around the buggy address:
  0x0c087fff7fc0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c087fff7fd0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c087fff7fe0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c087fff7ff0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x0c087fff8000: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
=>0x0c087fff8010: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m[[1m[0m02[1m[0m]
  0x0c087fff8020: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c087fff8030: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c087fff8040: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c087fff8050: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c087fff8060: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
Shadow byte legend (one shadow byte represents 8 application bytes):
  Addressable:           [1m[0m00[1m[0m
  Partially addressable: [1m[0m01[1m[0m [1m[0m02[1m[0m [1m[0m03[1m[0m [1m[0m04[1m[0m [1m[0m05[1m[0m [1m[0m06[1m[0m [1m[0m07[1m[0m
  Heap left redzone:       [1m[31mfa[1m[0m
  Freed heap region:       [1m[35mfd[1m[0m
  Stack left redzone:      [1m[31mf1[1m[0m
  Stack mid redzone:       [1m[31mf2[1m[0m
  Stack right redzone:     [1m[31mf3[1m[0m
  Stack after return:      [1m[35mf5[1m[0m
  Stack use after scope:   [1m[35mf8[1m[0m
  Global redzone:          [1m[31mf9[1m[0m
  Global init order:       [1m[36mf6[1m[0m
  Poisoned by user:        [1m[34mf7[1m[0m
  Container overflow:      [1m[34mfc[1m[0m
  Array cookie:            [1m[31mac[1m[0m
  Intra object redzone:    [1m[33mbb[1m[0m
  ASan internal:           [1m[33mfe[1m[0m
  Left alloca redzone:     [1m[34mca[1m[0m
  Right alloca redzone:    [1m[34mcb[1m[0m
  Shadow gap:              [1m[0mcc[1m[0m
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
