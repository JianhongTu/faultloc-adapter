## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/epan/dissectors/packet-ieee80211.c b/epan/dissectors/packet-ieee80211.c
index 5347845f02..1c14c81cc0 100644
--- a/epan/dissectors/packet-ieee80211.c
+++ b/epan/dissectors/packet-ieee80211.c
@@ -14336,9 +14336,8 @@ add_tagged_field(packet_info *pinfo, proto_tree *tree, tvbuff_t *tvb, int offset
   ieee80211_tagged_field_data_t field_data;
   gboolean      isDMG;
 
-  gboolean     *p_isDMG = ((gboolean*)(p_get_proto_data(wmem_file_scope(), pinfo, proto_wlan, IS_DMG_KEY)));
+  isDMG = GPOINTER_TO_INT(p_get_proto_data(wmem_file_scope(), pinfo, proto_wlan, IS_DMG_KEY));
 
-  isDMG   = p_isDMG ? *p_isDMG : FALSE;
   tag_no  = tvb_get_guint8(tvb, offset);
   tag_len = tvb_get_guint8(tvb, offset + 1);
 
@@ -17169,7 +17168,7 @@ dissect_ieee80211_common(tvbuff_t *tvb, packet_info *pinfo,
 
   AIRPDCAP_KEY_ITEM  used_key;
 
-  p_add_proto_data(wmem_file_scope(), pinfo, proto_wlan, IS_DMG_KEY, &isDMG);
+  p_add_proto_data(wmem_file_scope(), pinfo, proto_wlan, IS_DMG_KEY, GINT_TO_POINTER(isDMG));
 
   whdr= &whdrs[0];
 
```

It touches these lines, which are the ones to avoid:

- `epan/dissectors/packet-ieee80211.c` lines 14339-14339
- `epan/dissectors/packet-ieee80211.c` lines 14341-14341
- `epan/dissectors/packet-ieee80211.c` lines 17172-17172

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Stack-use-after-return READ 4
- Instrumentation: asan
- Entry point: fuzzshark_ip

```
oss-fuzz configured for dissector: ip
INFO: Seed: 4199184597
INFO: Loaded 1 modules (279610 guards): [0xc40b350, 0xc51c438),
/out/fuzzshark_ip: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
=================================================================
[1m[31m==7==ERROR: AddressSanitizer: stack-use-after-return on address 0x7ffff3b629b0 at pc 0x00000112b9a1 bp 0x7fffffffc090 sp 0x7fffffffc088
[1m[0m[1m[34mREAD of size 4 at 0x7ffff3b629b0 thread T0[1m[0m
SCARINESS: 55 (4-byte-read-stack-use-after-return)
    #0 0x112b9a0 in add_tagged_field /src/wireshark/epan/dissectors/packet-ieee80211.c:14341:23
    #1 0x114855a in ieee_80211_add_tagged_parameters /src/wireshark/epan/dissectors/packet-ieee80211.c:16782:19
    #2 0x112fbac in dissect_data_encap /src/wireshark/epan/dissectors/packet-ieee80211.c:19562:7
    #3 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #4 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #5 0x5ade93 in dissector_try_uint_new /src/wireshark/epan/packet.c:1329:8
    #6 0x5ae418 in dissector_try_uint /src/wireshark/epan/packet.c:1353:9
    #7 0xeb28ff in dissect_ethertype /src/wireshark/epan/dissectors/packet-ethertype.c:267:21
    #8 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #9 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #10 0x5ab9aa in call_dissector_with_data /src/wireshark/epan/packet.c:3005:8
    #11 0xeb0971 in dissect_eth_common /src/wireshark/epan/dissectors/packet-eth.c:536:5
    #12 0xeae81c in dissect_eth_withoutfcs /src/wireshark/epan/dissectors/packet-eth.c:810:3
    #13 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #14 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #15 0x5ab9aa in call_dissector_with_data /src/wireshark/epan/packet.c:3005:8
    #16 0x17c7039 in dissect_bcp_bpdu /src/wireshark/epan/dissectors/packet-ppp.c
    #17 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #18 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #19 0x5ade93 in dissector_try_uint_new /src/wireshark/epan/packet.c:1329:8
    #20 0x5ae418 in dissector_try_uint /src/wireshark/epan/packet.c:1353:9
    #21 0x17cef59 in dissect_ppp_common /src/wireshark/epan/dissectors/packet-ppp.c:4838:10
    #22 0x17bdd08 in dissect_ppp_raw_hdlc /src/wireshark/epan/dissectors/packet-ppp.c:6072:17
    #23 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #24 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #25 0x5ade93 in dissector_try_uint_new /src/wireshark/epan/packet.c:1329:8
    #26 0x5ae418 in dissector_try_uint /src/wireshark/epan/packet.c:1353:9
    #27 0xf5d5ae in dissect_gre /src/wireshark/epan/dissectors/packet-gre.c:512:14
    #28 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #29 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #30 0x5ade93 in dissector_try_uint_new /src/wireshark/epan/packet.c:1329:8
    #31 0x11a873d in ip_try_dissect /src/wireshark/epan/dissectors/packet-ip.c:1854:7
    #32 0x11de893 in ipv6_dissect_next /src/wireshark/epan/dissectors/packet-ipv6.c:2414:9
    #33 0x11df917 in dissect_ipv6 /src/wireshark/epan/dissectors/packet-ipv6.c:2362:5
    #34 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #35 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #36 0x5ab9aa in call_dissector_with_data /src/wireshark/epan/packet.c:3005:8
    #37 0x11a8e93 in dissect_ip /src/wireshark/epan/dissectors/packet-ip.c:2343:5
    #38 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #39 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #40 0x5b40ec in call_all_postdissectors /src/wireshark/epan/packet.c:3339:3
    #41 0xf16518 in dissect_frame /src/wireshark/epan/dissectors/packet-frame.c:623:5
    #42 0x5b5372 in call_dissector_through_handle /src/wireshark/epan/packet.c:684:8
    #43 0x5ae1d2 in call_dissector_work /src/wireshark/epan/packet.c:759:9
    #44 0x5ab9aa in call_dissector_with_data /src/wireshark/epan/packet.c:3005:8
    #45 0x5ab165 in dissect_record /src/wireshark/epan/packet.c:567:3
    #46 0x5a0265 in epan_dissect_run /src/wireshark/epan/epan.c:461:2
    #47 0x517ea1 in LLVMFuzzerTestOneInput /src/wireshark/tools/oss-fuzzshark.c:296:2
    #48 0x541189 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/libfuzzer/FuzzerLoop.cpp:451:13
    #49 0x54195a in fuzzer::Fuzzer::RunOne(unsigned char const*, unsigned long) /src/libfuzzer/FuzzerLoop.cpp:408:3
    #50 0x5192a6 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/libfuzzer/FuzzerDriver.cpp:268:6
    #51 0x5244e1 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/libfuzzer/FuzzerDriver.cpp:683:9
    #52 0x5188d8 in main /src/libfuzzer/FuzzerMain.cpp:20:10
    #53 0x7ffff6ee682f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)
    #54 0x41eea8 in _start (/out/fuzzshark_ip+0x41eea8)

DEDUP_TOKEN: add_tagged_field--ieee_80211_add_tagged_parameters--dissect_data_encap
[1m[32mAddress 0x7ffff3b629b0 is located in stack of thread T0 at offset 432 in frame[1m[0m
[1m[0m    #0 0x113da2f in dissect_ieee80211_common /src/wireshark/epan/dissectors/packet-ieee80211.c:17125

DEDUP_TOKEN: dissect_ieee80211_common
  This frame has 11 object(s):
    [32, 40) 'cw_item' (line 17132)
    [64, 320) 'out_buff' (line 17145)
    [384, 388) 'iv_buff' (line 17147)
    [400, 410) 'flag_str' (line 17152)
    [432, 436) 'isDMG' (line 17161)[1m[32m <== Memory access at offset 432 is inside this variable[1m[0m
    [448, 656) 'used_key' (line 17170)
    [720, 740) 'key' (line 18422)
    [784, 785) 'algorithm' (line 18496)
    [800, 804) 'sec_header' (line 18500)
    [816, 820) 'sec_trailer' (line 18501)
    [832, 840) 'msdu_tvb' (line 18846)
HINT: this may be a false positive if your program uses some custom stack unwind mechanism or swapcontext
      (longjmp and C++ exceptions *are* supported)
SUMMARY: AddressSanitizer: stack-use-after-return /src/wireshark/epan/dissectors/packet-ieee80211.c:14341:23 in add_tagged_field
Shadow bytes around the buggy address:
  0x10007e7644e0: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e7644f0: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e764500: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e764510: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e764520: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
=>0x10007e764530: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m[[1m[35mf5[1m[0m][1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e764540: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e764550: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e764560: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e764570: [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m [1m[35mf5[1m[0m
  0x10007e764580: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
Shadow byte legend (one shadow byte represents 8 application bytes):
  Addressable:           [1m[0m00[1m[0m
  Partially addressable: [1m[0m01[1m[0m [1m[0m02[1m[0m [1m[0m03[1m[0m [1m[0m04[1m[0m [1m[0m05[1m[0m [1m[0m06[1m[0m [1m[0m07[1m[0m
  Heap left redzone:       [1m[31mfa[1m[0m
  Freed heap region:       [1m[35mfd[1m[0m
  Stack left redzone:      [1m[31mf1[1m[0m
  Stack mid redzone:       [1m[31mf2[1m[0m
  Stack right redzone:     [1m[31mf3[1m[0m
  Stack after return:      [1m[35mf5[1m[0m
  Stack use after scope:   [1m[35mf8[1m[0m
  Global redzone:          [1m[31mf9[1m[0m
  Global init order:       [1m[36mf6[1m[0m
  Poisoned by user:        [1m[34mf7[1m[0m
  Container overflow:      [1m[34mfc[1m[0m
  Array cookie:            [1m[31mac[1m[0m
  Intra object redzone:    [1m[33mbb[1m[0m
  ASan internal:           [1m[33mfe[1m[0m
  Left alloca redzone:     [1m[34mca[1m[0m
  Right alloca redzone:    [1m[34mcb[1m[0m
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
