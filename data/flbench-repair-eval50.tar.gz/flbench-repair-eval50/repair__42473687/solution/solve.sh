#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/core/common/encoding.hpp b/src/core/common/encoding.hpp
index bf35678a0..786c8aa4f 100644
--- a/src/core/common/encoding.hpp
+++ b/src/core/common/encoding.hpp
@@ -76,7 +76,7 @@ inline uint32_t Reverse32(uint32_t v)
     return v;
 }
 
-#define BitVectorBytes(x) (((x) + (CHAR_BIT - 1)) / CHAR_BIT)
+#define BitVectorBytes(x) static_cast<uint8_t>(((x) + (CHAR_BIT - 1)) / CHAR_BIT)
 
 namespace BigEndian {
 
diff --git a/src/core/thread/network_data_tlvs.hpp b/src/core/thread/network_data_tlvs.hpp
index 26de34ad2..4de23f10f 100644
--- a/src/core/thread/network_data_tlvs.hpp
+++ b/src/core/thread/network_data_tlvs.hpp
@@ -345,7 +345,8 @@ public:
     bool IsValid(void) const
     {
         return ((GetLength() >= sizeof(*this) - sizeof(NetworkDataTlv)) &&
-                (GetLength() >= BitVectorBytes(mPrefixLength) + sizeof(*this) - sizeof(NetworkDataTlv)));
+                (GetLength() >= BitVectorBytes(mPrefixLength) + sizeof(*this) - sizeof(NetworkDataTlv)) &&
+                (BitVectorBytes(mPrefixLength) <= sizeof(Ip6::Address)));
     }
 
     /**

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42473687: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
