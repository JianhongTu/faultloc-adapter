#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/include/h2o/http2_scheduler.h b/include/h2o/http2_scheduler.h
index 02102bab6..daab136d3 100644
--- a/include/h2o/http2_scheduler.h
+++ b/include/h2o/http2_scheduler.h
@@ -108,6 +108,7 @@ static h2o_http2_scheduler_node_t *h2o_http2_scheduler_get_parent(h2o_http2_sche
  * if any resource should be allocated
  */
 void h2o_http2_scheduler_activate(h2o_http2_scheduler_openref_t *ref);
+void h2o_http2_scheduler_deactivate(h2o_http2_scheduler_openref_t *ref);
 /**
  * calls the callback of the references linked to the dependency tree one by one, in the order defined by the dependency and the
  * weight.
diff --git a/lib/http2/connection.c b/lib/http2/connection.c
index 1c8d192a8..7b2e41608 100644
--- a/lib/http2/connection.c
+++ b/lib/http2/connection.c
@@ -266,6 +266,7 @@ static void preserve_stream_scheduler(h2o_http2_conn_t *conn, h2o_http2_stream_t
 
     (*dst)->stream_id = src->stream_id;
     h2o_http2_scheduler_relocate(&(*dst)->_scheduler, &src->_scheduler);
+    h2o_http2_scheduler_deactivate(&(*dst)->_scheduler);
 }
 
 void h2o_http2_conn_unregister_stream(h2o_http2_conn_t *conn, h2o_http2_stream_t *stream)
diff --git a/lib/http2/scheduler.c b/lib/http2/scheduler.c
index 461dfc305..bcaa4f187 100644
--- a/lib/http2/scheduler.c
+++ b/lib/http2/scheduler.c
@@ -341,6 +341,14 @@ void h2o_http2_scheduler_dispose(h2o_http2_scheduler_node_t *root)
     root->_queue = NULL;
 }
 
+void h2o_http2_scheduler_deactivate(h2o_http2_scheduler_openref_t *ref)
+{
+    if (!ref->_self_is_active)
+        return;
+    ref->_self_is_active = 0;
+    decr_active_cnt(&ref->node);
+}
+
 void h2o_http2_scheduler_activate(h2o_http2_scheduler_openref_t *ref)
 {
     if (ref->_self_is_active)

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42472316: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
