#!/bin/bash
set -u
mkdir -p /logs/verifier
rm -f /logs/verifier/reward.json /logs/verifier/reward.txt
python3 /tests/repair_score.py \
  --source /workspace/src \
  --baseline harbor-baseline \
  --gold-spans /tests/gold_spans.json \
  --local-id 42522068 \
  --test-timeout 2100 \
  --artifacts /logs/artifacts \
  --out /logs/verifier/reward.json
cat /logs/verifier/reward.json
