#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/libxslt/pattern.c b/libxslt/pattern.c
index 81655660..00298392 100644
--- a/libxslt/pattern.c
+++ b/libxslt/pattern.c
@@ -311,10 +311,6 @@ xsltCompMatchAdd(xsltParserContextPtr ctxt, xsltCompMatchPtr comp,
 	     "xsltCompMatchAdd: memory re-allocation failure.\n");
 	    if (ctxt->style != NULL)
 		ctxt->style->errors++;
-	    if (value)
-	        xmlFree(value);
-	    if (value2)
-	        xmlFree(value2);
 	    return (-1);
 	}
         comp->maxStep *= 2;

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42522260: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
