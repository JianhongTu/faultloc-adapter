#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/include/open62541/server.h b/include/open62541/server.h
index 3c208a0a8..15b1f7bcb 100644
--- a/include/open62541/server.h
+++ b/include/open62541/server.h
@@ -311,7 +311,7 @@ UA_ServerConfig_setCustomHostname(UA_ServerConfig *config,
 /* Creates a new server. Moves the config into the server with a shallow copy.
  * The config content is cleared together with the server. */
 UA_Server UA_EXPORT *
-UA_Server_newWithConfig(const UA_ServerConfig *config);
+UA_Server_newWithConfig(UA_ServerConfig *config);
 
 void UA_EXPORT UA_Server_delete(UA_Server *server);
 
diff --git a/plugins/ua_config_default.c b/plugins/ua_config_default.c
index f53c493f3..ba916c391 100644
--- a/plugins/ua_config_default.c
+++ b/plugins/ua_config_default.c
@@ -51,12 +51,7 @@ UA_Server_new() {
         return NULL;
     }
 
-    UA_Server *server = UA_Server_newWithConfig(&config);
-    if(!server) {
-        config.nodestore.clear(config.nodestore.context);
-    }
-
-    return server;
+    return UA_Server_newWithConfig(&config);
 }
 
 /*******************************/
diff --git a/src/server/ua_server.c b/src/server/ua_server.c
index c422c8888..41bc5f330 100644
--- a/src/server/ua_server.c
+++ b/src/server/ua_server.c
@@ -339,13 +339,16 @@ UA_Server_init(UA_Server *server) {
 }
 
 UA_Server *
-UA_Server_newWithConfig(const UA_ServerConfig *config) {
+UA_Server_newWithConfig(UA_ServerConfig *config) {
     if(!config)
         return NULL;
     UA_Server *server = (UA_Server *)UA_calloc(1, sizeof(UA_Server));
-    if(!server)
+    if(!server) {
+        UA_ServerConfig_clean(config);
         return NULL;
+    }
     server->config = *config;
+    memset(config, 0, sizeof(UA_ServerConfig));
     return UA_Server_init(server);
 }
 

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42486724: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
