## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/av1/av1_dx_iface.c b/av1/av1_dx_iface.c
index c440fedb4a..db8c931cb3 100644
--- a/av1/av1_dx_iface.c
+++ b/av1/av1_dx_iface.c
@@ -193,6 +193,8 @@ static aom_codec_err_t decoder_peek_si_internal(const uint8_t *data,
                                                 aom_codec_stream_info_t *si,
                                                 int *is_intra_only) {
   int intra_only_flag = 0;
+  int got_sequence_header = 0;
+  int found_keyframe = 0;
 
   if (data + data_sz <= data || data_sz < 1) return AOM_CODEC_INVALID_PARAM;
 
@@ -200,20 +202,11 @@ static aom_codec_err_t decoder_peek_si_internal(const uint8_t *data,
   si->h = 0;
   si->is_kf = 0;
 
-  // TODO(tomfinegan): This function needs Sequence and Frame Header OBUs to
-  // operate properly. At present it hard codes the values to 1 for the keyframe
-  // and intra only flags, and assumes the data being parsed is a Sequence
-  // Header OBU.
-  // NOTE(david.barker): In addition, this code currently requires the video
-  // stream to begin with an optional OBU_TEMPORAL_DELIMITER followed by an
-  // OBU_SEQUENCE_HEADER.
-  intra_only_flag = 1;
-  si->is_kf = 1;
-
   ObuHeader obu_header;
   memset(&obu_header, 0, sizeof(obu_header));
   size_t payload_size = 0;
   size_t bytes_read = 0;
+  int reduced_still_picture_hdr = 0;
   aom_codec_err_t status = aom_read_obu_header_and_size(
       data, data_sz, si->is_annexb, &obu_header, &payload_size, &bytes_read);
   if (status != AOM_CODEC_OK) return status;
@@ -230,35 +223,60 @@ static aom_codec_err_t decoder_peek_si_internal(const uint8_t *data,
         data, data_sz, si->is_annexb, &obu_header, &payload_size, &bytes_read);
     if (status != AOM_CODEC_OK) return status;
   }
+  while (1) {
+    data += bytes_read;
+    data_sz -= bytes_read;
+    const uint8_t *payload_start = data;
+    if (obu_header.type == OBU_SEQUENCE_HEADER) {
+      if (data_sz < 2) return AOM_CODEC_CORRUPT_FRAME;
+      struct aom_read_bit_buffer rb = { data, data + data_sz, 0, NULL, NULL };
+
+      av1_read_profile(&rb);  // profile
+      const int still_picture = aom_rb_read_bit(&rb);
+      reduced_still_picture_hdr = aom_rb_read_bit(&rb);
+
+      if (!still_picture && reduced_still_picture_hdr) {
+        return AOM_CODEC_UNSUP_BITSTREAM;
+      }
 
-  // Check that the selected OBU is a sequence header
-  if (obu_header.type != OBU_SEQUENCE_HEADER) return AOM_CODEC_UNSUP_BITSTREAM;
-
-  // Read a few values from the sequence header payload
-  data += bytes_read;
-  data_sz -= bytes_read;
-  struct aom_read_bit_buffer rb = { data, data + data_sz, 0, NULL, NULL };
-
-  av1_read_profile(&rb);  // profile
-  const int still_picture = aom_rb_read_bit(&rb);
-  const int reduced_still_picture_hdr = aom_rb_read_bit(&rb);
-
-  if (!still_picture && reduced_still_picture_hdr) {
-    return AOM_CODEC_UNSUP_BITSTREAM;
-  }
+      if (parse_operating_points(&rb, reduced_still_picture_hdr, si) !=
+          AOM_CODEC_OK) {
+        return AOM_CODEC_ERROR;
+      }
 
-  if (parse_operating_points(&rb, reduced_still_picture_hdr, si) !=
-      AOM_CODEC_OK) {
-    return AOM_CODEC_ERROR;
+      int num_bits_width = aom_rb_read_literal(&rb, 4) + 1;
+      int num_bits_height = aom_rb_read_literal(&rb, 4) + 1;
+      int max_frame_width = aom_rb_read_literal(&rb, num_bits_width) + 1;
+      int max_frame_height = aom_rb_read_literal(&rb, num_bits_height) + 1;
+      si->w = max_frame_width;
+      si->h = max_frame_height;
+      got_sequence_header = 1;
+    } else if (obu_header.type == OBU_FRAME_HEADER ||
+               obu_header.type == OBU_FRAME) {
+      if (got_sequence_header && reduced_still_picture_hdr) {
+        found_keyframe = 1;
+        break;
+      } else {
+        if (data_sz < 1) return AOM_CODEC_CORRUPT_FRAME;
+        struct aom_read_bit_buffer rb = { data, data + data_sz, 0, NULL, NULL };
+        const int show_existing_frame = aom_rb_read_bit(&rb);
+        if (!show_existing_frame) {
+          const FRAME_TYPE frame_type = (FRAME_TYPE)aom_rb_read_literal(&rb, 2);
+          if (frame_type == KEY_FRAME) {
+            found_keyframe = 1;
+            break;
+          }
+        }
+      }
+    }
+    data = payload_start + payload_size;
+    data_sz -= payload_size;
+    if (data_sz <= 0) break;
+    status = aom_read_obu_header_and_size(
+        data, data_sz, si->is_annexb, &obu_header, &payload_size, &bytes_read);
+    if (status != AOM_CODEC_OK) return status;
   }
-
-  int num_bits_width = aom_rb_read_literal(&rb, 4) + 1;
-  int num_bits_height = aom_rb_read_literal(&rb, 4) + 1;
-  int max_frame_width = aom_rb_read_literal(&rb, num_bits_width) + 1;
-  int max_frame_height = aom_rb_read_literal(&rb, num_bits_height) + 1;
-  si->w = max_frame_width;
-  si->h = max_frame_height;
-
+  if (got_sequence_header && found_keyframe) si->is_kf = 1;
   if (is_intra_only != NULL) *is_intra_only = intra_only_flag;
   return AOM_CODEC_OK;
 }
```

It touches these lines, which are the ones to avoid:

- `av1/av1_dx_iface.c` lines 195-196
- `av1/av1_dx_iface.c` lines 203-212
- `av1/av1_dx_iface.c` lines 234-248
- `av1/av1_dx_iface.c` lines 250-252
- `av1/av1_dx_iface.c` lines 254-261

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Index-out-of-bounds
- Instrumentation: ubsan
- Entry point: av1_dec_fuzzer_threaded

```
INFO: Seed: 3636744101
INFO: Loaded 1 modules   (72039 inline 8-bit counters): 72039 [0x127f800, 0x1291167),
INFO: Loaded 1 PC tables (72039 PCs): 72039 [0x1291168,0x13aa7d8),
/out/av1_dec_fuzzer_threaded: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
[1m/src/aom/av1/common/seg_common.h:65:27:[1m[31m runtime error: [1m[0m[1mindex -2 out of bounds for type 'unsigned int const[8]'[1m[0m
    #0 0x48ef57 in segfeature_active /src/aom/av1/common/seg_common.h:65:27
    #1 0x48ef57 in read_skip /src/aom/av1/decoder/decodemv.c:439
    #2 0x48ef57 in read_intra_frame_mode_info /src/aom/av1/decoder/decodemv.c:738
    #3 0x48ef57 in av1_read_mode_info /src/aom/av1/decoder/decodemv.c:1585
    #4 0x47c9f9 in decode_mbmi_block /src/aom/av1/decoder/decodeframe.c:329:3
    #5 0x47c9f9 in decode_block /src/aom/av1/decoder/decodeframe.c:1279
    #6 0x47be54 in decode_partition /src/aom/av1/decoder/decodeframe.c:1426:7
    #7 0x47bd2b in decode_partition /src/aom/av1/decoder/decodeframe.c:1417:7
    #8 0x47ac94 in decode_tile_sb_row /src/aom/av1/decoder/decodeframe.c:2487:5
    #9 0x47ac94 in decode_tile /src/aom/av1/decoder/decodeframe.c:2533
    #10 0x47a414 in tile_worker_hook /src/aom/av1/decoder/decodeframe.c:2737:5
    #11 0xbe5067 in execute /src/aom/aom_util/aom_thread.c:135:27
    #12 0xbe5067 in thread_loop /src/aom/aom_util/aom_thread.c:44
    #13 0x7ffff78b86b9 in start_thread (/lib/x86_64-linux-gnu/libpthread.so.0+0x76b9)
    #14 0x7ffff6fcc41c in clone (/lib/x86_64-linux-gnu/libc.so.6+0x10741c)

DEDUP_TOKEN: segfeature_active--read_skip--read_intra_frame_mode_info
SUMMARY: UndefinedBehaviorSanitizer: undefined-behavior /src/aom/av1/common/seg_common.h:65:27 in

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
