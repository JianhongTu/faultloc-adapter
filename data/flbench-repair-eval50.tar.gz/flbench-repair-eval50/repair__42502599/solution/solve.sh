#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/pj_apply_vgridshift.c b/src/pj_apply_vgridshift.c
index 3c7cc210..6435b954 100644
--- a/src/pj_apply_vgridshift.c
+++ b/src/pj_apply_vgridshift.c
@@ -92,33 +92,33 @@ static double pj_read_vgrid_value( PJ *defn, LP input, int *gridlist_count_p, PJ
             return PJD_ERR_FAILED_TO_LOAD_GRID;
         }
 
-    }
 
-    /* Interpolation a location within the grid */
-    grid_x = (input.lam - ct->ll.lam) / ct->del.lam;
-    grid_y = (input.phi - ct->ll.phi) / ct->del.phi;
-    grid_ix = (int) floor(grid_x);
-    grid_iy = (int) floor(grid_y);
-    grid_x -= grid_ix;
-    grid_y -= grid_iy;
-
-    grid_ix2 = grid_ix + 1;
-    if( grid_ix2 >= ct->lim.lam )
-        grid_ix2 = ct->lim.lam - 1;
-    grid_iy2 = grid_iy + 1;
-    if( grid_iy2 >= ct->lim.phi )
-        grid_iy2 = ct->lim.phi - 1;
-
-    cvs = (float *) ct->cvs;
-    value = cvs[grid_ix + grid_iy * ct->lim.lam]
-        * (1.0-grid_x) * (1.0-grid_y)
-        + cvs[grid_ix2 + grid_iy * ct->lim.lam]
-        * (grid_x) * (1.0-grid_y)
-        + cvs[grid_ix + grid_iy2 * ct->lim.lam]
-        * (1.0-grid_x) * (grid_y)
-        + cvs[grid_ix2 + grid_iy2 * ct->lim.lam]
-        * (grid_x) * (grid_y);
+        /* Interpolation a location within the grid */
+        grid_x = (input.lam - ct->ll.lam) / ct->del.lam;
+        grid_y = (input.phi - ct->ll.phi) / ct->del.phi;
+        grid_ix = (int) floor(grid_x);
+        grid_iy = (int) floor(grid_y);
+        grid_x -= grid_ix;
+        grid_y -= grid_iy;
+
+        grid_ix2 = grid_ix + 1;
+        if( grid_ix2 >= ct->lim.lam )
+            grid_ix2 = ct->lim.lam - 1;
+        grid_iy2 = grid_iy + 1;
+        if( grid_iy2 >= ct->lim.phi )
+            grid_iy2 = ct->lim.phi - 1;
+
+        cvs = (float *) ct->cvs;
+        value = cvs[grid_ix + grid_iy * ct->lim.lam]
+            * (1.0-grid_x) * (1.0-grid_y)
+            + cvs[grid_ix2 + grid_iy * ct->lim.lam]
+            * (grid_x) * (1.0-grid_y)
+            + cvs[grid_ix + grid_iy2 * ct->lim.lam]
+            * (1.0-grid_x) * (grid_y)
+            + cvs[grid_ix2 + grid_iy2 * ct->lim.lam]
+            * (grid_x) * (grid_y);
 
+    }
     /* nodata?  */
     /* GTX official nodata value if  -88.88880f, but some grids also */
     /* use other  big values for nodata (e.g naptrans2008.gtx has */

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42502599: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
