## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/src/pj_apply_vgridshift.c b/src/pj_apply_vgridshift.c
index 3c7cc210..6435b954 100644
--- a/src/pj_apply_vgridshift.c
+++ b/src/pj_apply_vgridshift.c
@@ -92,33 +92,33 @@ static double pj_read_vgrid_value( PJ *defn, LP input, int *gridlist_count_p, PJ
             return PJD_ERR_FAILED_TO_LOAD_GRID;
         }
 
-    }
 
-    /* Interpolation a location within the grid */
-    grid_x = (input.lam - ct->ll.lam) / ct->del.lam;
-    grid_y = (input.phi - ct->ll.phi) / ct->del.phi;
-    grid_ix = (int) floor(grid_x);
-    grid_iy = (int) floor(grid_y);
-    grid_x -= grid_ix;
-    grid_y -= grid_iy;
-
-    grid_ix2 = grid_ix + 1;
-    if( grid_ix2 >= ct->lim.lam )
-        grid_ix2 = ct->lim.lam - 1;
-    grid_iy2 = grid_iy + 1;
-    if( grid_iy2 >= ct->lim.phi )
-        grid_iy2 = ct->lim.phi - 1;
-
-    cvs = (float *) ct->cvs;
-    value = cvs[grid_ix + grid_iy * ct->lim.lam]
-        * (1.0-grid_x) * (1.0-grid_y)
-        + cvs[grid_ix2 + grid_iy * ct->lim.lam]
-        * (grid_x) * (1.0-grid_y)
-        + cvs[grid_ix + grid_iy2 * ct->lim.lam]
-        * (1.0-grid_x) * (grid_y)
-        + cvs[grid_ix2 + grid_iy2 * ct->lim.lam]
-        * (grid_x) * (grid_y);
+        /* Interpolation a location within the grid */
+        grid_x = (input.lam - ct->ll.lam) / ct->del.lam;
+        grid_y = (input.phi - ct->ll.phi) / ct->del.phi;
+        grid_ix = (int) floor(grid_x);
+        grid_iy = (int) floor(grid_y);
+        grid_x -= grid_ix;
+        grid_y -= grid_iy;
+
+        grid_ix2 = grid_ix + 1;
+        if( grid_ix2 >= ct->lim.lam )
+            grid_ix2 = ct->lim.lam - 1;
+        grid_iy2 = grid_iy + 1;
+        if( grid_iy2 >= ct->lim.phi )
+            grid_iy2 = ct->lim.phi - 1;
+
+        cvs = (float *) ct->cvs;
+        value = cvs[grid_ix + grid_iy * ct->lim.lam]
+            * (1.0-grid_x) * (1.0-grid_y)
+            + cvs[grid_ix2 + grid_iy * ct->lim.lam]
+            * (grid_x) * (1.0-grid_y)
+            + cvs[grid_ix + grid_iy2 * ct->lim.lam]
+            * (1.0-grid_x) * (grid_y)
+            + cvs[grid_ix2 + grid_iy2 * ct->lim.lam]
+            * (grid_x) * (grid_y);
 
+    }
     /* nodata?  */
     /* GTX official nodata value if  -88.88880f, but some grids also */
     /* use other  big values for nodata (e.g naptrans2008.gtx has */
```

It touches these lines, which are the ones to avoid:

- `src/pj_apply_vgridshift.c` lines 95-95
- `src/pj_apply_vgridshift.c` lines 97-120

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: UNKNOWN READ
- Instrumentation: asan
- Entry point: standard_fuzzer

```
INFO: Seed: 2860676478
INFO: Loaded 1 modules   (5219 guards): 5219 [0x967400, 0x96c58c),
/out/standard_fuzzer: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
AddressSanitizer:DEADLYSIGNAL
=================================================================
[1m[31m==7==ERROR: AddressSanitizer: SEGV on unknown address 0x0000bfff0530 (pc 0x0000005afa8c bp 0x7fffffffdc50 sp 0x7fffffffdbf0 T0)
[1m[0m==7==The signal is caused by a READ memory access.
SCARINESS: 20 (wild-addr-read)
    #0 0x5afa8b in pj_read_vgrid_value /src/proj.4/src/pj_apply_vgridshift.c:113:13
    #1 0x5b008c in proj_vgrid_value /src/proj.4/src/pj_apply_vgridshift.c:289:13
    #2 0x5ccc32 in reverse_3d /src/proj.4/src/PJ_vgridshift.c:29:24
    #3 0x62855e in pj_inv3d /src/proj.4/src/pj_inv3d.c:41:11
    #4 0x5a3fb5 in pj_transform /src/proj.4/src/pj_transform.c:197:32
    #5 0x51a7c5 in LLVMFuzzerTestOneInput /src/proj.4/./test/fuzzers/standard_fuzzer.cpp
    #6 0x53bed0 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/libfuzzer/FuzzerLoop.cpp:471:13
    #7 0x51b415 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/libfuzzer/FuzzerDriver.cpp:273:6
    #8 0x526ae5 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/libfuzzer/FuzzerDriver.cpp:690:9
    #9 0x51aab8 in main /src/libfuzzer/FuzzerMain.cpp:20:10
    #10 0x7ffff6ee582f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)
    #11 0x41c728 in _start (/out/standard_fuzzer+0x41c728)

DEDUP_TOKEN: pj_read_vgrid_value--proj_vgrid_value--reverse_3d
AddressSanitizer can not provide additional info.
SUMMARY: AddressSanitizer: SEGV /src/proj.4/src/pj_apply_vgridshift.c:113:13 in pj_read_vgrid_value
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
