## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/SAX2.c b/SAX2.c
index 0f261b7b..49ce566c 100644
--- a/SAX2.c
+++ b/SAX2.c
@@ -1665,7 +1665,10 @@ xmlSAX2StartElement(void *ctx, const xmlChar *fullname, const xmlChar **atts)
 #ifdef DEBUG_SAX_TREE
     xmlGenericError(xmlGenericErrorContext, "pushing(%s)\n", name);
 #endif
-    nodePush(ctxt, ret);
+    if (nodePush(ctxt, ret) < 0) {
+        xmlFreeNode(ret);
+        return;
+    }
 
     /*
      * Link the child element
@@ -2336,7 +2339,10 @@ xmlSAX2StartElementNs(void *ctx,
     /*
      * We are parsing a new node.
      */
-    nodePush(ctxt, ret);
+    if (nodePush(ctxt, ret) < 0) {
+        xmlFreeNode(ret);
+        return;
+    }
 
     /*
      * Link the child element
```

It touches these lines, which are the ones to avoid:

- `SAX2.c` lines 1668-1668
- `SAX2.c` lines 2339-2339

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Heap-use-after-free READ 1
- Instrumentation: asan
- Entry point: xmlsec_fuzzer

```
INFO: Seed: 4290135821
INFO: Loaded 1 modules   (56276 inline 8-bit counters): 56276 [0xe948a8, 0xea247c),
INFO: Loaded 1 PC tables (56276 PCs): 56276 [0xabb420,0xb97160),
/out/xmlsec_fuzzer: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
=================================================================
[1m[31m==7==ERROR: AddressSanitizer: heap-use-after-free on address 0x625000002992 at pc 0x0000004eb25d bp 0x7ffffffe12d0 sp 0x7ffffffe0a80
[1m[0m[1m[34mREAD of size 1 at 0x625000002992 thread T0[1m[0m
SCARINESS: 40 (1-byte-read-heap-use-after-free)
    #0 0x4eb25c in __asan_memcpy /src/llvm/projects/compiler-rt/lib/asan/asan_interceptors_memintrinsics.cc:23
    #1 0x80f92d in xmlStrndup /src/libxml2/xmlstring.c:50:5
    #2 0x8a50c3 in xmlSAX2TextNode /src/libxml2/SAX2.c:1902:17
    #3 0x8a29f4 in xmlSAX2AttributeNs /src/libxml2/SAX2.c:2065:8
    #4 0x8a1dee in xmlSAX2StartElementNs /src/libxml2/SAX2.c
    #5 0x6d3eb0 in xmlParseStartTag2 /src/libxml2/parser.c:9583:6
    #6 0x6cfb29 in xmlParseElement /src/libxml2/parser.c:9928:16
    #7 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #8 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #9 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #10 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #11 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #12 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #13 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #14 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #15 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #16 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #17 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #18 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #19 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #20 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #21 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #22 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #23 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #24 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #25 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #26 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #27 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #28 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #29 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #30 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #31 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #32 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #33 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #34 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #35 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #36 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #37 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #38 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #39 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #40 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #41 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #42 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #43 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #44 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #45 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #46 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #47 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #48 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #49 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #50 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #51 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #52 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #53 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #54 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #55 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #56 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #57 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #58 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #59 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #60 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #61 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #62 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #63 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #64 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #65 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #66 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #67 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #68 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #69 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #70 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #71 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #72 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #73 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #74 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #75 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #76 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #77 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #78 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #79 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #80 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #81 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #82 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #83 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #84 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #85 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #86 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #87 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #88 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #89 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #90 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #91 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #92 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #93 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #94 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #95 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #96 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #97 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #98 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #99 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #100 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #101 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #102 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #103 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #104 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #105 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #106 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #107 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #108 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #109 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #110 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #111 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #112 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #113 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #114 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #115 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #116 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #117 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #118 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #119 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #120 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #121 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #122 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #123 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #124 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #125 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #126 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #127 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #128 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #129 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #130 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #131 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #132 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #133 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #134 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #135 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #136 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #137 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #138 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #139 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #140 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #141 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #142 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #143 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #144 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #145 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #146 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #147 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #148 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #149 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #150 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #151 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #152 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #153 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #154 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #155 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #156 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #157 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #158 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #159 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #160 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #161 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #162 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #163 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #164 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #165 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #166 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #167 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #168 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #169 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #170 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #171 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #172 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #173 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #174 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #175 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #176 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #177 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #178 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #179 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #180 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #181 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #182 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #183 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #184 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #185 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #186 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #187 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #188 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #189 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #190 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #191 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #192 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #193 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #194 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #195 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #196 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #197 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #198 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #199 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #200 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #201 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #202 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #203 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #204 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #205 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #206 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #207 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #208 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #209 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #210 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #211 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #212 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #213 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #214 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #215 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #216 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #217 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #218 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #219 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #220 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #221 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #222 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #223 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #224 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #225 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #226 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #227 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #228 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #229 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #230 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #231 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #232 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #233 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #234 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #235 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #236 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #237 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #238 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #239 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #240 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #241 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #242 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #243 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #244 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #245 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #246 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #247 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #248 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #249 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #250 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #251 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #252 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5

DEDUP_TOKEN: __asan_memcpy--xmlStrndup--xmlSAX2TextNode
[1m[32m0x625000002992 is located 146 bytes inside of 8194-byte region [0x625000002900,0x625000004902)
[1m[0m[1m[35mfreed by thread T0 here:[1m[0m
    #0 0x4ec260 in __interceptor_free /src/llvm/projects/compiler-rt/lib/asan/asan_malloc_linux.cc:124
    #1 0x813f1a in xmlBufFree /src/libxml2/buf.c
    #2 0x72b265 in xmlFreeParserInputBuffer /src/libxml2/xmlIO.c:2479:9
    #3 0x695b84 in xmlHaltParser /src/libxml2/parser.c:12466:13
    #4 0x695549 in nodePush /src/libxml2/parser.c:1788:2
    #5 0x8a1998 in xmlSAX2StartElementNs /src/libxml2/SAX2.c:2339:5
    #6 0x6d3eb0 in xmlParseStartTag2 /src/libxml2/parser.c:9583:6
    #7 0x6cfb29 in xmlParseElement /src/libxml2/parser.c:9928:16
    #8 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #9 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #10 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #11 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #12 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #13 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #14 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #15 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #16 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #17 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #18 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #19 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #20 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #21 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #22 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #23 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #24 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #25 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #26 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #27 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #28 0x6cf117 in xmlParseContent /src/libxml2/parser.c:9846:6
    #29 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5

DEDUP_TOKEN: __interceptor_free--xmlBufFree--xmlFreeParserInputBuffer
[1m[35mpreviously allocated by thread T0 here:[1m[0m
    #0 0x4ec62f in malloc /src/llvm/projects/compiler-rt/lib/asan/asan_malloc_linux.cc:146
    #1 0x81355f in xmlBufCreateSize /src/libxml2/buf.c:172:36
    #2 0x72ad13 in xmlAllocParserInputBuffer /src/libxml2/xmlIO.c:2333:19
    #3 0x72d11c in xmlParserInputBufferCreateMem /src/libxml2/xmlIO.c:2932:11
    #4 0x6e9eb1 in xmlCreateMemoryParserCtxt /src/libxml2/parser.c:14384:11
    #5 0x6c7c75 in xmlParseBalancedChunkMemoryInternal /src/libxml2/parser.c:13367:12
    #6 0x6c51a2 in xmlParseReference /src/libxml2/parser.c:7110:12
    #7 0x6cee21 in xmlParseContent /src/libxml2/parser.c:9855:6
    #8 0x6d00ff in xmlParseElement /src/libxml2/parser.c:10014:5
    #9 0x6d99b0 in xmlParseDocument /src/libxml2/parser.c:10711:2
    #10 0x533f34 in xmlSecParseMemory /src/xmlsec/src/parser.c:556:11
    #11 0x530b4c in LLVMFuzzerTestOneInput /src/xmlsec/tests/oss-fuzz/xmlsec_target.c:12:21
    #12 0x598eb8 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/libfuzzer/FuzzerLoop.cpp:570:15
    #13 0x56f38a in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/libfuzzer/FuzzerDriver.cpp:280:6
    #14 0x57ac03 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/libfuzzer/FuzzerDriver.cpp:713:9
    #15 0x56ea0c in main /src/libfuzzer/FuzzerMain.cpp:20:10
    #16 0x7ffff6ccb82f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)

DEDUP_TOKEN: malloc--xmlBufCreateSize--xmlAllocParserInputBuffer
SUMMARY: AddressSanitizer: heap-use-after-free /src/llvm/projects/compiler-rt/lib/asan/asan_interceptors_memintrinsics.cc:23 in __asan_memcpy
Shadow bytes around the buggy address:
  0x0c4a7fff84e0: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c4a7fff84f0: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c4a7fff8500: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c4a7fff8510: [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m [1m[31mfa[1m[0m
  0x0c4a7fff8520: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
=>0x0c4a7fff8530: [1m[35mfd[1m[0m [1m[35mfd[1m[0m[[1m[35mfd[1m[0m][1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c4a7fff8540: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c4a7fff8550: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c4a7fff8560: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c4a7fff8570: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
  0x0c4a7fff8580: [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m [1m[35mfd[1m[0m
Shadow byte legend (one shadow byte represents 8 application bytes):
  Addressable:           [1m[0m00[1m[0m
  Partially addressable: [1m[0m01[1m[0m [1m[0m02[1m[0m [1m[0m03[1m[0m [1m[0m04[1m[0m [1m[0m05[1m[0m [1m[0m06[1m[0m [1m[0m07[1m[0m
  Heap left redzone:       [1m[31mfa[1m[0m
  Freed heap region:       [1m[35mfd[1m[0m
  Stack left redzone:      [1m[31mf1[1m[0m
  Stack mid redzone:       [1m[31mf2[1m[0m
  Stack right redzone:     [1m[31mf3[1m[0m
  Stack after return:      [1m[35mf5[1m[0m
  Stack use after scope:   [1m[35mf8[1m[0m
  Global redzone:          [1m[31mf9[1m[0m
  Global init order:       [1m[36mf6[1m[0m
  Poisoned by user:        [1m[34mf7[1m[0m
  Container overflow:      [1m[34mfc[1m[0m
  Array cookie:            [1m[31mac[1m[0m
  Intra object redzone:    [1m[33mbb[1m[0m
  ASan internal:           [1m[33mfe[1m[0m
  Left alloca redzone:     [1m[34mca[1m[0m
  Right alloca redzone:    [1m[34mcb[1m[0m
  Shadow gap:              [1m[0mcc[1m[0m
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
