## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/rtcp.c b/rtcp.c
index 8364e335..fcee0af1 100644
--- a/rtcp.c
+++ b/rtcp.c
@@ -168,7 +168,9 @@ static void janus_rtcp_incoming_sr(janus_rtcp_context *ctx, janus_rtcp_sr *sr) {
 
 /* Helper to handle an incoming transport-cc feedback: triggered by a call to janus_rtcp_fix_ssrc a valid context pointer */
 static void janus_rtcp_incoming_transport_cc(janus_rtcp_context *ctx, janus_rtcp_fb *twcc, int total) {
-	if(ctx == NULL || twcc == NULL || total < 16)
+	if(ctx == NULL || twcc == NULL || total < 20)
+		return;
+	if(!janus_rtcp_check_fci((janus_rtcp_header *)twcc, total, 4))
 		return;
 	/* Parse the header first */
 	uint8_t *data = (uint8_t *)twcc->fci;
@@ -185,7 +187,7 @@ static void janus_rtcp_incoming_transport_cc(janus_rtcp_context *ctx, janus_rtcp
 	JANUS_LOG(LOG_HUGE, "[TWCC] seq=%"SCNu16", psc=%"SCNu16", ref=%"SCNu32", fbpc=%"SCNu8"\n",
 		base_seq, status_count, reference, fb_pkt);
 	/* Now traverse the feedback: packet chunks first, and then recv deltas */
-	total -= 16;
+	total -= 20;
 	data += 8;
 	int psc = status_count;
 	uint16_t chunk = 0;
@@ -229,6 +231,9 @@ static void janus_rtcp_incoming_transport_cc(janus_rtcp_context *ctx, janus_rtcp
 		total -= 2;
 		data += 2;
 	}
+	if(psc > 0) {
+		return;
+	}
 	/* Iterate on all recv deltas */
 	JANUS_LOG(LOG_HUGE, "[TWCC] Recv Deltas (%d/%"SCNu16"):\n", g_list_length(list), status_count);
 	num = 0;
```

It touches these lines, which are the ones to avoid:

- `rtcp.c` lines 171-171
- `rtcp.c` lines 188-188
- `rtcp.c` lines 231-232

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Dynamic-stack-buffer-overflow READ 2
- Instrumentation: asan
- Entry point: rtcp_fuzzer

```
======================= INFO =========================
This binary is built for AFL-fuzz.
To run the target function on individual input(s) execute this:
  /out/rtcp_fuzzer < INPUT_FILE
or
  /out/rtcp_fuzzer INPUT_FILE1 [INPUT_FILE2 ... ]
To fuzz with afl-fuzz execute this:
  afl-fuzz [afl-flags] /out/rtcp_fuzzer [-N]
afl-fuzz will run N iterations before re-spawning the process (default: 1000)
======================================================
Reading 24 bytes from /tmp/poc
=================================================================
[1m[31m==7==ERROR: AddressSanitizer: dynamic-stack-buffer-overflow on address 0x7ffd84bd0778 at pc 0x0000004d5b6b bp 0x7ffd84bcd8d0 sp 0x7ffd84bcd8c8
[1m[0m[1m[34mREAD of size 2 at 0x7ffd84bd0778 thread T0[1m[0m
SCARINESS: 29 (2-byte-read-dynamic-stack-buffer-overflow)
    #0 0x4d5b6a in janus_rtcp_incoming_transport_cc /src/janus-gateway/rtcp.c:199:3
    #1 0x4cde57 in janus_rtcp_fix_ssrc /src/janus-gateway/rtcp.c:560:6
    #2 0x4ca949 in LLVMFuzzerTestOneInput /src/janus-gateway/fuzzers/rtcp_fuzzer.c:56:2
    #3 0x4caebe in ExecuteFilesOnyByOne /src/libfuzzer/afl/afl_driver.cpp:216:5
    #4 0x4caebe in main /src/libfuzzer/afl/afl_driver.cpp:253:12
    #5 0x7fbc4aa9282f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2082f)
    #6 0x41f1d8 in _start (/out/rtcp_fuzzer+0x41f1d8)

DEDUP_TOKEN: janus_rtcp_incoming_transport_cc--janus_rtcp_fix_ssrc--LLVMFuzzerTestOneInput
[1m[32mAddress 0x7ffd84bd0778 is located in stack of thread T0 at offset 9272 in frame[1m[0m
[1m[0m    #0 0x4cc8cf in janus_rtcp_fix_ssrc /src/janus-gateway/rtcp.c:432

DEDUP_TOKEN: janus_rtcp_fix_ssrc
  This frame has 93 object(s):
    [32, 96) 'janus_log_ts' (line 437)
    [128, 256) 'janus_log_src' (line 437)
    [288, 344) 'janustmresult' (line 437)
    [384, 392) 'janusltime' (line 437)
    [416, 480) 'janus_log_ts29' (line 448)
    [512, 640) 'janus_log_src30' (line 448)
    [672, 728) 'janustmresult33' (line 448)
    [768, 776) 'janusltime34' (line 448)
    [800, 864) 'janus_log_ts100' (line 464)
    [896, 1024) 'janus_log_src101' (line 464)
    [1056, 1112) 'janustmresult104' (line 464)
    [1152, 1160) 'janusltime105' (line 464)
    [1184, 1248) 'janus_log_ts181' (line 480)
    [1280, 1408) 'janus_log_src182' (line 480)
    [1440, 1496) 'janustmresult185' (line 480)
    [1536, 1544) 'janusltime186' (line 480)
    [1568, 1632) 'janus_log_ts229' (line 490)
    [1664, 1792) 'janus_log_src230' (line 490)
    [1824, 1880) 'janustmresult233' (line 490)
    [1920, 1928) 'janusltime234' (line 490)
    [1952, 2016) 'janus_log_ts278' (line 500)
    [2048, 2176) 'janus_log_src279' (line 500)
    [2208, 2264) 'janustmresult282' (line 500)
    [2304, 2312) 'janusltime283' (line 500)
    [2336, 2400) 'janus_log_ts326' (line 510)
    [2432, 2560) 'janus_log_src327' (line 510)
    [2592, 2648) 'janustmresult330' (line 510)
    [2688, 2696) 'janusltime331' (line 510)
    [2720, 2784) 'janus_log_ts358' (line 521)
    [2816, 2944) 'janus_log_src359' (line 521)
    [2976, 3032) 'janustmresult362' (line 521)
    [3072, 3080) 'janusltime363' (line 521)
    [3104, 3168) 'janus_log_ts429' (line 530)
    [3200, 3328) 'janus_log_src430' (line 530)
    [3360, 3416) 'janustmresult433' (line 530)
    [3456, 3464) 'janusltime434' (line 530)
    [3488, 3508) 'bitmask' (line 535)
    [3552, 3616) 'janus_log_ts503' (line 545)
    [3648, 3776) 'janus_log_src504' (line 545)
    [3808, 3864) 'janustmresult507' (line 545)
    [3904, 3912) 'janusltime508' (line 545)
    [3936, 4000) 'janus_log_ts539' (line 550)
    [4032, 4160) 'janus_log_src540' (line 550)
    [4192, 4248) 'janustmresult543' (line 550)
    [4288, 4296) 'janusltime544' (line 550)
    [4320, 4384) 'janus_log_ts597' (line 562)
    [4416, 4544) 'janus_log_src598' (line 562)
    [4576, 4632) 'janustmresult601' (line 562)
    [4672, 4680) 'janusltime602' (line 562)
    [4704, 4768) 'janus_log_ts658' (line 577)
    [4800, 4928) 'janus_log_src659' (line 577)
    [4960, 5016) 'janustmresult662' (line 577)
    [5056, 5064) 'janusltime663' (line 577)
    [5088, 5152) 'janus_log_ts713' (line 586)
    [5184, 5312) 'janus_log_src714' (line 586)
    [5344, 5400) 'janustmresult717' (line 586)
    [5440, 5448) 'janusltime718' (line 586)
    [5472, 5536) 'janus_log_ts741' (line 588)
    [5568, 5696) 'janus_log_src742' (line 588)
    [5728, 5784) 'janustmresult745' (line 588)
    [5824, 5832) 'janusltime746' (line 588)
    [5856, 5920) 'janus_log_ts769' (line 591)
    [5952, 6080) 'janus_log_src770' (line 591)
    [6112, 6168) 'janustmresult773' (line 591)
    [6208, 6216) 'janusltime774' (line 591)
    [6240, 6304) 'janus_log_ts844' (line 602)
    [6336, 6464) 'janus_log_src845' (line 602)
    [6496, 6552) 'janustmresult848' (line 602)
    [6592, 6600) 'janusltime849' (line 602)
    [6624, 6688) 'janus_log_ts929' (line 615)
    [6720, 6848) 'janus_log_src930' (line 615)
    [6880, 6936) 'janustmresult933' (line 615)
    [6976, 6984) 'janusltime934' (line 615)
    [7008, 7072) 'janus_log_ts998' (line 629)
    [7104, 7232) 'janus_log_src999' (line 629)
    [7264, 7320) 'janustmresult1002' (line 629)
    [7360, 7368) 'janusltime1003' (line 629)
    [7392, 7456) 'janus_log_ts1044' (line 632)
    [7488, 7616) 'janus_log_src1045' (line 632)
    [7648, 7704) 'janustmresult1048' (line 632)
    [7744, 7752) 'janusltime1049' (line 632)
    [7776, 7840) 'janus_log_ts1072' (line 635)
    [7872, 8000) 'janus_log_src1073' (line 635)
    [8032, 8088) 'janustmresult1076' (line 635)
    [8128, 8136) 'janusltime1077' (line 635)
    [8160, 8224) 'janus_log_ts1153' (line 652)
    [8256, 8384) 'janus_log_src1154' (line 652)
    [8416, 8472) 'janustmresult1157' (line 652)
    [8512, 8520) 'janusltime1158' (line 652)
    [8544, 8608) 'janus_log_ts1202' (line 657)
    [8640, 8768) 'janus_log_src1203' (line 657)
    [8800, 8856) 'janustmresult1206' (line 657)
    [8896, 8904) 'janusltime1207' (line 657)[1m[32m <== Memory access at offset 9272 overflows this variable[1m[0m
HINT: this may be a false positive if your program uses some custom stack unwind mechanism, swapcontext or vfork
      (longjmp and C++ exceptions *are* supported)
SUMMARY: AddressSanitizer: dynamic-stack-buffer-overflow /src/janus-gateway/rtcp.c:199:3 in janus_rtcp_incoming_transport_cc
Shadow bytes around the buggy address:
  0x100030972090: [1m[35mf8[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m
  0x1000309720a0: [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m
  0x1000309720b0: [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[35mf8[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m [1m[31mf2[1m[0m
  0x1000309720c0: [1m[35mf8[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[31mf3[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x1000309720d0: [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m
=>0x1000309720e0: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m[[1m[34mcb[1m[0m]
  0x1000309720f0: [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m
  0x100030972100: [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[34mca[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[34mcb[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x100030972110: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x100030972120: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
  0x100030972130: [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m [1m[0m00[1m[0m
Shadow byte legend (one shadow byte represents 8 application bytes):
  Addressable:           [1m[0m00[1m[0m
  Partially addressable: [1m[0m01[1m[0m [1m[0m02[1m[0m [1m[0m03[1m[0m [1m[0m04[1m[0m [1m[0m05[1m[0m [1m[0m06[1m[0m [1m[0m07[1m[0m
  Heap left redzone:       [1m[31mfa[1m[0m
  Freed heap region:       [1m[35mfd[1m[0m
  Stack left redzone:      [1m[31mf1[1m[0m
  Stack mid redzone:       [1m[31mf2[1m[0m
  Stack right redzone:     [1m[31mf3[1m[0m
  Stack after return:      [1m[35mf5[1m[0m
  Stack use after scope:   [1m[35mf8[1m[0m
  Global redzone:          [1m[31mf9[1m[0m
  Global init order:       [1m[36mf6[1m[0m
  Poisoned by user:        [1m[34mf7[1m[0m
  Container overflow:      [1m[34mfc[1m[0m
  Array cookie:            [1m[31mac[1m[0m
  Intra object redzone:    [1m[33mbb[1m[0m
  ASan internal:           [1m[33mfe[1m[0m
  Left alloca redzone:     [1m[34mca[1m[0m
  Right alloca redzone:    [1m[34mcb[1m[0m
  Shadow gap:              [1m[0mcc[1m[0m
==7==ABORTING

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
