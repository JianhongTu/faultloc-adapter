#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/librawspeed/decoders/CrwDecoder.cpp b/src/librawspeed/decoders/CrwDecoder.cpp
index d130aa3d..b818b198 100644
--- a/src/librawspeed/decoders/CrwDecoder.cpp
+++ b/src/librawspeed/decoders/CrwDecoder.cpp
@@ -62,7 +62,8 @@ RawImage CrwDecoder::decodeRawInternal() {
   uint32 width = sensorInfo->getU16(1);
   uint32 height = sensorInfo->getU16(2);
 
-  if (width == 0 || height == 0 || width > 4104 || height > 3048)
+  if (width == 0 || height == 0 || width % 4 != 0 || width > 4104 ||
+      height > 3048)
     ThrowRDE("Unexpected image dimensions found: (%u; %u)", width, height);
 
   const CiffEntry* decTable = mRootIFD->getEntryRecursive(CIFF_DECODERTABLE);
diff --git a/src/librawspeed/decompressors/CrwDecompressor.cpp b/src/librawspeed/decompressors/CrwDecompressor.cpp
index cd6bcd39..eed6133f 100644
--- a/src/librawspeed/decompressors/CrwDecompressor.cpp
+++ b/src/librawspeed/decompressors/CrwDecompressor.cpp
@@ -272,43 +272,24 @@ void CrwDecompressor::decompress(const RawImage& mRaw, const Buffer* mFile,
     }
   }
 
-  // Add the uncompressed 2 low bits to the decoded 8 high bits
   if (lowbits) {
     offset = 26;
-    ByteStream lowbitInput(mFile, offset, height * width / 4);
 
-    for (uint32 j = 0; j < height;) {
-      // Process 8 rows or however are left
-      const uint32 lines = min(height - j, 8U);
+    const unsigned lBlocks = 1 * height * width / 4;
+    ByteStream lowbitInput(mFile, offset, lBlocks);
 
-      // Process 8 rows or however are left
-      const uint32 nBlocks = width / 4 * lines;
-      if (nBlocks <= 0)
-        ThrowRDE("Image too small, not even a single block.");
+    for (uint32 j = 0; j < height; j++) {
+      auto* dest = reinterpret_cast<ushort16*>(mRaw->getData(0, j));
 
-      ushort16* dest = nullptr;
+      for (uint32 i = 0; i < width;) {
+        const uchar8 c = lowbitInput.getByte();
 
-      uint32 i = 0;
-
-      for (uint32 block = 0; block < nBlocks; block++) {
-        auto c = static_cast<uint32>(lowbitInput.getByte());
-
-        // Process 8 bits in pairs
-        for (uint32 r = 0; r < 8; r += 2) {
-          if (i % width == 0) {
-            // new line
-            i = 0;
-
-            dest = reinterpret_cast<ushort16*>(mRaw->getData(0, j));
-
-            j++;
-          }
-
-          assert(dest);
-          ushort16 val = (*dest << 2) | ((c >> r) & 0x0003);
+        for (uint32 p = 0; p < 4; p++) {
+          ushort16 low = (c >> (2 * p)) & 0b11;
+          ushort16 val = (*dest << 2) | low;
 
           if (width == 2672 && val < 512)
-            val += 2; // No idea why this is needed
+            val += 2;
 
           *dest = val;
           i++;

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42498104: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
