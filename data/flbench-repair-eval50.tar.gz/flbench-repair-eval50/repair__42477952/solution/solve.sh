#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/libexslt/crypto.c b/libexslt/crypto.c
index ac390387..621fd904 100644
--- a/libexslt/crypto.c
+++ b/libexslt/crypto.c
@@ -755,7 +755,14 @@ exsltCryptoRc4DecryptFunction (xmlXPathParserContextPtr ctxt, int nargs) {
     PLATFORM_RC4_DECRYPT (ctxt, padkey, bin, ret_len, ret, ret_len);
     ret[ret_len] = 0;
 
-    xmlXPathReturnString (ctxt, ret);
+    if (xmlCheckUTF8(ret) == 0) {
+	xsltTransformError(tctxt, NULL, tctxt->inst,
+	    "exsltCryptoRc4DecryptFunction: Invalid UTF-8\n");
+        xmlFree(ret);
+	xmlXPathReturnEmptyString(ctxt);
+    } else {
+        xmlXPathReturnString(ctxt, ret);
+    }
 
 done:
     if (key != NULL)

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42477952: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
