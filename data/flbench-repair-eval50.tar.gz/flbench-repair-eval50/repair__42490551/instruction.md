## Task

A test input makes this C/C++ program misbehave at runtime. The maintainers tracked the bug down and fixed it, and **their fix is reproduced below**. It works — but it may not be the only place the program could have been corrected.

That is the question here: **can this same bug be fixed somewhere else in the code?**

So this isn't a request to reproduce the maintainers' fix. Copying it, rewording it, shifting it a few lines, or adding to it doesn't tell us anything new. What's interesting is whether there's a *second* place — usually further upstream, where the wrong value, size, lifetime, or ownership relationship first comes into being — at which the program could have been made correct instead.

Unlike most tasks of this kind, **you can build and test.** `build.sh` compiles your working tree and `run_poc.sh` runs the reproducer against what you built. Use them: a claimed alternative that has not compiled and run clean is not an answer. Iterate as much as you need within your time budget.

A workable order:

1. Read the diagnostic report and find the failure site in the source.
2. Read the maintainers' fix and work out **what property of the program it restores**, and where. You will have to state this either way, so do it first.
3. Trace **backwards** from the failure site to where that property first stops holding. That's where an alternative fix would live.
4. Edit the source to restore the same property at that earlier point — or a stronger one that implies it — without touching the lines the maintainers' fix touches.
5. Run `build.sh`, then `run_poc.sh`. Iterate until it compiles and the reproducer runs clean, or until you're satisfied no such fix exists.
6. If you have `run_tests.sh`, run it and confirm you have broken nothing.
7. Write your summary. This is required in every case, including when you find nothing.

## The Maintainers' Fix

This is the change that was accepted upstream. **Don't apply it, and don't edit the lines it edits.** It's here as evidence about what the bug actually is, and to mark the region your own change should stay clear of.

```diff
diff --git a/libsepol/cil/src/cil_resolve_ast.c b/libsepol/cil/src/cil_resolve_ast.c
index f6deb100..3153a3d4 100644
--- a/libsepol/cil/src/cil_resolve_ast.c
+++ b/libsepol/cil/src/cil_resolve_ast.c
@@ -51,6 +51,7 @@ struct cil_args_resolve {
 	struct cil_db *db;
 	enum cil_pass pass;
 	uint32_t *changed;
+	struct cil_list *disabled_optionals;
 	struct cil_tree_node *optstack;
 	struct cil_tree_node *boolif;
 	struct cil_tree_node *macro;
@@ -3852,7 +3853,7 @@ int __cil_resolve_ast_last_child_helper(struct cil_tree_node *current, void *ext
 
 		if (((struct cil_optional *)parent->data)->enabled == CIL_FALSE) {
 			*(args->changed) = CIL_TRUE;
-			cil_tree_children_destroy(parent);
+			cil_list_append(args->disabled_optionals, CIL_NODE, parent);
 		}
 
 		/* pop off the stack */
@@ -3915,6 +3916,7 @@ int cil_resolve_ast(struct cil_db *db, struct cil_tree_node *current)
 	extra_args.in_list = NULL;
 	extra_args.blockstack = NULL;
 
+	cil_list_init(&extra_args.disabled_optionals, CIL_NODE);
 	cil_list_init(&extra_args.sidorder_lists, CIL_LIST_ITEM);
 	cil_list_init(&extra_args.classorder_lists, CIL_LIST_ITEM);
 	cil_list_init(&extra_args.unordered_classorder_lists, CIL_LIST_ITEM);
@@ -3982,6 +3984,7 @@ int cil_resolve_ast(struct cil_db *db, struct cil_tree_node *current)
 		}
 
 		if (changed && (pass > CIL_PASS_CALL1)) {
+			struct cil_list_item *item;
 			/* Need to re-resolve because an optional was disabled that contained
 			 * one or more declarations. We only need to reset to the call1 pass 
 			 * because things done in the preceding passes aren't allowed in 
@@ -4010,6 +4013,11 @@ int cil_resolve_ast(struct cil_db *db, struct cil_tree_node *current)
 				cil_log(CIL_ERR, "Failed to reset declarations\n");
 				goto exit;
 			}
+			cil_list_for_each(item, extra_args.disabled_optionals) {
+				cil_tree_children_destroy(item->data);
+			}
+			cil_list_destroy(&extra_args.disabled_optionals, CIL_FALSE);
+			cil_list_init(&extra_args.disabled_optionals, CIL_NODE);
 		}
 
 		/* reset the arguments */
@@ -4038,6 +4046,7 @@ exit:
 	__cil_ordered_lists_destroy(&extra_args.catorder_lists);
 	__cil_ordered_lists_destroy(&extra_args.sensitivityorder_lists);
 	__cil_ordered_lists_destroy(&extra_args.unordered_classorder_lists);
+	cil_list_destroy(&extra_args.disabled_optionals, CIL_FALSE);
 	cil_list_destroy(&extra_args.in_list, CIL_FALSE);
 
 	return rc;
```

It touches these lines, which are the ones to avoid:

- `libsepol/cil/src/cil_resolve_ast.c` lines 53-54
- `libsepol/cil/src/cil_resolve_ast.c` lines 3855-3855
- `libsepol/cil/src/cil_resolve_ast.c` lines 3917-3918
- `libsepol/cil/src/cil_resolve_ast.c` lines 3984-3985
- `libsepol/cil/src/cil_resolve_ast.c` lines 4012-4013
- `libsepol/cil/src/cil_resolve_ast.c` lines 4040-4041

## Source Code

The source is a git working tree at `/workspace/src`. Edit it in place — no need to commit, your final working tree is what's evaluated. The fix above has **not** been applied to it; the tree is the original, still-broken revision.

## Diagnostic Report

This is what an instrumented build printed when the reproducer was run against the original source.

**Failure details:**
- Failure type: Use-of-uninitialized-value
- Instrumentation: msan
- Entry point: secilc-fuzzer

```
INFO: Running with entropic power schedule (0xFF, 100).
INFO: Seed: 4069995860
INFO: Loaded 1 modules   (14419 inline 8-bit counters): 14419 [0x9b6178, 0x9b99cb),
INFO: Loaded 1 PC tables (14419 PCs): 14419 [0x9b99d0,0x9f1f00),
/out/secilc-fuzzer: Running 1 inputs 1 time(s) each.
Running: /tmp/poc
Failed to find sensitivity
[1m[31m==7==WARNING: MemorySanitizer: use-of-uninitialized-value
[1m[0m    #0 0x70fd0b in cil_reset_classperms_list /src/selinux/libsepol/src/../cil/src/cil_reset_ast.c:67:6
    #1 0x70d875 in cil_reset_classpermission /src/selinux/libsepol/src/../cil/src/cil_reset_ast.c:55:2
    #2 0x70fdf9 in cil_reset_classperms_set /src/selinux/libsepol/src/../cil/src/cil_reset_ast.c:60:2
    #3 0x70fc69 in cil_reset_classperms_list /src/selinux/libsepol/src/../cil/src/cil_reset_ast.c:75:4
    #4 0x70d875 in cil_reset_classpermission /src/selinux/libsepol/src/../cil/src/cil_reset_ast.c:55:2
    #5 0x70d199 in __cil_reset_node /src/selinux/libsepol/src/../cil/src/cil_reset_ast.c:423:3
    #6 0x63dca1 in cil_tree_walk_core /src/selinux/libsepol/src/../cil/src/cil_tree.c:272:9
    #7 0x63e40e in cil_tree_walk /src/selinux/libsepol/src/../cil/src/cil_tree.c:316:7
    #8 0x63df18 in cil_tree_walk_core /src/selinux/libsepol/src/../cil/src/cil_tree.c:284:9
    #9 0x63e40e in cil_tree_walk /src/selinux/libsepol/src/../cil/src/cil_tree.c:316:7
    #10 0x70f8fd in cil_reset_ast /src/selinux/libsepol/src/../cil/src/cil_reset_ast.c:585:7
    #11 0x636911 in cil_resolve_ast /src/selinux/libsepol/src/../cil/src/cil_resolve_ast.c:4008:9
    #12 0x54b7dc in cil_compile /src/selinux/libsepol/src/../cil/src/cil.c:550:7
    #13 0x525314 in LLVMFuzzerTestOneInput /src/secilc-fuzzer.c:59:6
    #14 0x459b31 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerLoop.cpp:599:15
    #15 0x4438c2 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:323:6
    #16 0x449c05 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:856:9
    #17 0x473ab2 in main /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerMain.cpp:20:10
    #18 0x7ffff6ee583f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2083f)
    #19 0x41e7d8 in _start (/out/secilc-fuzzer+0x41e7d8)

DEDUP_TOKEN: cil_reset_classperms_list--cil_reset_classpermission--cil_reset_classperms_set
  [1m[35mUninitialized value was created by a heap deallocation[1m[0m
    #0 0x4ce669 in free /src/llvm-project/compiler-rt/lib/msan/msan_interceptors.cpp:222:3
    #1 0x59881b in cil_destroy_classpermission /src/selinux/libsepol/src/../cil/src/cil_build_ast.c:806:2
    #2 0x54c4a8 in cil_destroy_data /src/selinux/libsepol/src/../cil/src/cil.c:678:3
    #3 0x63da3a in cil_tree_node_destroy /src/selinux/libsepol/src/../cil/src/cil_tree.c:235:4
    #4 0x63d647 in cil_tree_children_destroy /src/selinux/libsepol/src/../cil/src/cil_tree.c
    #5 0x635bdf in __cil_resolve_ast_last_child_helper /src/selinux/libsepol/src/../cil/src/cil_resolve_ast.c:3855:4
    #6 0x63e505 in cil_tree_walk /src/selinux/libsepol/src/../cil/src/cil_tree.c:322:8
    #7 0x63df18 in cil_tree_walk_core /src/selinux/libsepol/src/../cil/src/cil_tree.c:284:9
    #8 0x63e40e in cil_tree_walk /src/selinux/libsepol/src/../cil/src/cil_tree.c:316:7
    #9 0x63df18 in cil_tree_walk_core /src/selinux/libsepol/src/../cil/src/cil_tree.c:284:9
    #10 0x63e40e in cil_tree_walk /src/selinux/libsepol/src/../cil/src/cil_tree.c:316:7
    #11 0x636114 in cil_resolve_ast /src/selinux/libsepol/src/../cil/src/cil_resolve_ast.c:3926:8
    #12 0x54b7dc in cil_compile /src/selinux/libsepol/src/../cil/src/cil.c:550:7
    #13 0x525314 in LLVMFuzzerTestOneInput /src/secilc-fuzzer.c:59:6
    #14 0x459b31 in fuzzer::Fuzzer::ExecuteCallback(unsigned char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerLoop.cpp:599:15
    #15 0x4438c2 in fuzzer::RunOneTest(fuzzer::Fuzzer*, char const*, unsigned long) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:323:6
    #16 0x449c05 in fuzzer::FuzzerDriver(int*, char***, int (*)(unsigned char const*, unsigned long)) /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerDriver.cpp:856:9
    #17 0x473ab2 in main /src/llvm-project/compiler-rt/lib/fuzzer/FuzzerMain.cpp:20:10
    #18 0x7ffff6ee583f in __libc_start_main (/lib/x86_64-linux-gnu/libc.so.6+0x2083f)

DEDUP_TOKEN: free--cil_destroy_classpermission--cil_destroy_data
SUMMARY: MemorySanitizer: use-of-uninitialized-value /src/selinux/libsepol/src/../cil/src/cil_reset_ast.c:67:6 in cil_reset_classperms_list
Unique heap origins: 458
Stack depot allocated bytes: 52488
Unique origin histories: 2
History depot allocated bytes: 48
Exiting

```

You are not given the reproducer input itself, only the ability to run it. That's deliberate: a fix should follow from the logic of the code, not from the particular bytes that happened to expose it.

---

## Available Tools

### Dedicated tools
- `build.sh` — compile your current working tree. Prints the compiler output; exit 0 means it built. Takes a while.
- `run_poc.sh` — run the reproducer against **the most recent successful build** and print a fresh diagnostic report. Exit 0 means it ran clean. Run `build.sh` first, or you are testing the original binary and will see the original failure no matter what you edited.
- `run_tests.sh` — run the project's own test suite against your current working tree. Slower than `build.sh`; the tree is rebuilt from scratch each time.

### The project's own test suite

Run it before you change anything and again after. **Exit 0 means you have broken nothing** — not that every test passes. Some of this project's tests already fail, and the script knows which; it checks only that what was passing still passes. The verifier runs the same script and reads the same exit code, so what you see is what it sees.

If you cannot find a change that leaves the suite as you found it, say so — that is a real result, and a far better one than a patch you know regresses.

---

## What a Good Answer Looks Like

Make a genuine, best-effort search. If a real alternative exists, it is usually a few call frames up from where the failure surfaces.

Your change should:

- **build** — `build.sh` exits 0;
- **stop the failure** — `run_poc.sh` exits 0 afterwards;
- **break nothing else** — where `run_tests.sh` exists, no test that passed before your change may fail after it;
- **be somewhere else** — no line you change falls inside the lines listed above, and it should differ from the maintainers' fix in substance, not just in wording or position;
- **address the root cause** — correct the faulty logic itself, for the whole family of inputs that could reach it.

That last point is the one that matters most, and it's where these attempts usually go wrong. **Suppressing the symptom is not fixing the bug.** A change that makes the reproducer pass without correcting the underlying defect looks like a success and isn't one. Examples:

- special-casing the exact sizes, offsets, types, or values named in the diagnostic report — you can't see the reproducer, but the report still names them, and a condition written around those numbers is fitted to one input;
- an early `return`/`goto`/bail-out that skips the failing path rather than making it correct;
- clamping, masking, or truncating a value where it's used so the access lands in range while the wrong value survives untouched;
- switching off or short-circuiting the feature the input exercises;
- widening a buffer, or relaxing a check, so the bad access happens to fit.

Each of those stops the failure. None of them fixes it. If your change would still be wrong for a slightly different input that reaches the same code, it belongs in this list.

Please change **program source only**. The reproducer, the entry-point harness, tests, build files, and instrumentation settings are the measuring setup rather than the program — editing those changes what's being measured instead of fixing anything, so leave them alone.

If you trace the defect and conclude there **isn't** a good fix outside the maintainers' lines, that is a perfectly good answer. Say so and leave the source unchanged; it's more useful than a change you don't believe in.

## Required: `/logs/artifacts/summary.json`

Before you exit, write a JSON object to `/logs/artifacts/summary.json`. This is required in **every** case, including when you find nothing — it is read later by someone who sees none of your other reasoning, so each field has to stand on its own. It is checked automatically, and a missing or malformed file is recorded as such.

```json
{
  "root_cause": "What property of the program is violated, and where the bad state FIRST arises -- not where it is detected. Name files and functions.",
  "gold_patch_explanation": "How the maintainers' change restores that property.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "Required when alternative_fix_exists is true. What your change restores; why it holds for the whole family of inputs that could reach that code, not just the one that was run; and how it differs from the maintainers' fix in SUBSTANCE -- a different point in the causal chain, a different property enforced, or a different mechanism. Say plainly why it is not their fix relocated. State what build.sh, run_poc.sh and -- if you have it -- run_tests.sh reported.",
  "no_alternative_explanation": null
}
```

Field rules:

- `root_cause` and `gold_patch_explanation` — **always required**, whatever you concluded.
- `alternative_fix_exists` — `true` only if you left a working change in the tree that you believe is a genuine alternative fix. `false` otherwise, including when you tried and could not.
- `alternative_patch_explanation` — required when `alternative_fix_exists` is `true`; `null` otherwise.
- `no_alternative_explanation` — required when `alternative_fix_exists` is `false`; `null` otherwise. Explain *why*: which alternative locations you considered, what you tried, and what ruled each one out. "The property can only be established at the point the maintainers chose, because ..." is the kind of answer worth having.

Exactly one of the last two is filled in; the other is `null`.

Be honest with `alternative_fix_exists`. It is cross-checked against what is actually in your working tree, and a claim that disagrees with the tree is recorded as an inconsistency — a truthful `false` is worth more than an overstated `true`.
