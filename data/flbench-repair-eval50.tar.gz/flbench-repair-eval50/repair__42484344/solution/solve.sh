#!/bin/bash
# Precondition check, not a solution. Read `compiled`/`poc_suppressed`, not `reward`.
set -eu
mkdir -p /logs/artifacts
cat > /tmp/gt.diff <<'PATCH_EOF'
diff --git a/src/euc_jp.c b/src/euc_jp.c
index 6ddd91c..bfe91bf 100644
--- a/src/euc_jp.c
+++ b/src/euc_jp.c
@@ -135,8 +135,13 @@ code_to_mbc(OnigCodePoint code, UChar *buf)
 {
   UChar *p = buf;
 
-  if ((code & 0xff0000) != 0) *p++ = (UChar )(((code >> 16) & 0xff));
-  if ((code &   0xff00) != 0) *p++ = (UChar )(((code >>  8) & 0xff));
+  if ((code & 0xff0000) != 0) {
+    *p++ = (UChar )(((code >> 16) & 0xff));
+    *p++ = (UChar )(((code >>  8) & 0xff));
+  }
+  else if ((code & 0xff00) != 0)
+    *p++ = (UChar )(((code >>  8) & 0xff));
+
   *p++ = (UChar )(code & 0xff);
 
 #if 1

PATCH_EOF
cd /workspace/src
patch -p1 < /tmp/gt.diff
cat > /logs/artifacts/summary.json <<'SUMMARY_EOF'
{
  "root_cause": "Precondition check for instance 42484344: this run applies the accepted developer patch rather than searching for an alternative, so no root-cause analysis was performed.",
  "gold_patch_explanation": "The developer patch is applied verbatim; `compiled` and `poc_suppressed` in the reward file record whether it builds and suppresses the reproducer on this instance.",
  "alternative_fix_exists": true,
  "alternative_patch_explanation": "The developer patch itself, applied verbatim. Declared true because a patch IS in the tree: `alternative_fix_exists: false` is the agent's way of saying it left nothing to evaluate, and the verifier takes it at its word and stops -- which would skip the build and the reproducer, the two things this run exists to check.",
  "no_alternative_explanation": null
}
SUMMARY_EOF
